import React, { useEffect, useRef } from "react";
import { Chapter } from "../types";

interface AtmosphereCanvasProps {
  currentChapter: Chapter;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  color: string;
  alpha: number;
  pulseSpeed: number;
  phase: number;
}

interface FloatingDNAHook {
  x: number;
  y: number;
  angle: number;
  length: number;
  amplitude: number;
  freq: number;
  color: string;
}

export default function AtmosphereCanvas({ currentChapter }: AtmosphereCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mouseRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0, active: false });
  const chapterRef = useRef<Chapter>(currentChapter);

  useEffect(() => {
    chapterRef.current = currentChapter;
  }, [currentChapter]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    // Dynamic resize handler
    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", handleResize);

    // Track mouse position with easing
    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current.targetX = e.clientX;
      mouseRef.current.targetY = e.clientY;
      mouseRef.current.active = true;
    };

    const handleMouseLeave = () => {
      mouseRef.current.active = false;
    };

    window.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseleave", handleMouseLeave);

    // Initialize premium starry background & active custom particles
    const particles: Particle[] = [];
    const particleCount = 120;

    const getChapterColors = (accent: string) => {
      switch (accent) {
        case "gold":
          return { main: "rgba(249, 217, 73, ", accent: "#f9d949", bgGlow: "rgba(249, 217, 73, 0.05)" };
        case "emerald":
          return { main: "rgba(46, 252, 158, ", accent: "#2efc9e", bgGlow: "rgba(46, 252, 158, 0.05)" };
        case "cyan":
          return { main: "rgba(0, 240, 255, ", accent: "#00f0ff", bgGlow: "rgba(0, 240, 255, 0.05)" };
        case "violet":
          return { main: "rgba(189, 52, 254, ", accent: "#bd34fe", bgGlow: "rgba(189, 52, 254, 0.05)" };
        default:
          return { main: "rgba(0, 240, 255, ", accent: "#00f0ff", bgGlow: "rgba(0, 240, 255, 0.05)" };
      }
    };

    // Create persistent star dots
    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.4,
        vy: (Math.random() - 0.5) * 0.4,
        size: Math.random() * 2 + 0.5,
        color: Math.random() > 0.5 ? "rgba(255, 255, 255, " : "rgba(100, 180, 255, ",
        alpha: Math.random() * 0.5 + 0.2,
        pulseSpeed: 0.005 + Math.random() * 0.01,
        phase: Math.random() * Math.PI * 2,
      });
    }

    // Abstract 3D structures rotating (proteins/organelles)
    let angle3D = 0;
    const structureNodesArgs = Array.from({ length: 15 }, () => ({
      x: (Math.random() - 0.5) * 200,
      y: (Math.random() - 0.5) * 200,
      z: (Math.random() - 0.5) * 200,
    }));

    // Render loop
    const render = () => {
      // Clear background with soft accumulation (simulates subtle trail)
      ctx.fillStyle = "rgba(2, 2, 5, 0.15)";
      ctx.fillRect(0, 0, width, height);

      const activeColorSet = getChapterColors(chapterRef.current.accentColor);

      // Interpolate mouse coordinates for fluid movement
      const mouse = mouseRef.current;
      mouse.x += (mouse.targetX - mouse.x) * 0.08;
      mouse.y += (mouse.targetY - mouse.y) * 0.08;

      // Draw active background nebula glow
      const grad = ctx.createRadialGradient(
        width / 2 + (mouse.x - width / 2) * 0.1,
        height / 2 + (mouse.y - height / 2) * 0.1,
        10,
        width / 2,
        height / 2,
        Math.max(width, height) * 0.7
      );
      grad.addColorStop(0, activeColorSet.bgGlow);
      grad.addColorStop(0.5, "rgba(5, 5, 12, 0.2)");
      grad.addColorStop(1, "rgba(2, 2, 5, 0.9)");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, width, height);

      // Draw floating cosmic particles
      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;

        // Boundary wrapping
        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        // Sinusoidal pulsing
        p.phase += p.pulseSpeed;
        const currentAlpha = p.alpha + Math.sin(p.phase) * 0.15;

        // Node interactive attraction/repulsion if mouse is near
        if (mouse.active) {
          const dx = mouse.x - p.x;
          const dy = mouse.y - p.y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 150) {
            const force = (150 - dist) / 150;
            // Push stars gently away
            p.x -= (dx / dist) * force * 0.5;
            p.y -= (dy / dist) * force * 0.5;
          }
        }

        ctx.beginPath();
        // Occasionally tint particles with chapter accent colors
        if (p.color.startsWith("rgba(255, 255, 255,")) {
          ctx.fillStyle = `rgba(255, 255, 255, ${Math.max(0.1, currentAlpha)})`;
        } else {
          ctx.fillStyle = activeColorSet.main + `${Math.max(0.1, currentAlpha * 0.8)})`;
        }
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      });

      // Chapter-specific visual canvas backdrops
      const chId = chapterRef.current.id;

      if (chId === 1) {
        // --- Hydrothermal Vents ---
        // Draw 3 primary vents rising from oceanic dark bottom
        const ventWidths = [120, 80, 100];
        const ventHeights = [height * 0.3, height * 0.45, height * 0.25];
        const ventOffsets = [width * 0.25, width * 0.5, width * 0.72];

        // Animated volcanic heat/bubbles
        ctx.fillStyle = "rgba(249, 217, 73, 0.02)";
        for (let idx = 0; idx < ventOffsets.length; idx++) {
          const vx = ventOffsets[idx];
          const vy = height - ventHeights[idx];

          // Draw vent silhouette
          ctx.beginPath();
          ctx.moveTo(vx - ventWidths[idx] / 2, height);
          ctx.quadraticCurveTo(vx - ventWidths[idx] / 4, vy + 40, vx - 15, vy);
          ctx.lineTo(vx + 15, vy);
          ctx.quadraticCurveTo(vx + ventWidths[idx] / 4, vy + 40, vx + ventWidths[idx] / 2, height);
          ctx.closePath();
          ctx.fillStyle = "rgba(10, 10, 18, 0.75)";
          ctx.strokeStyle = "rgba(249, 217, 73, 0.15)";
          ctx.lineWidth = 2;
          ctx.fill();
          ctx.stroke();

          // Render heat ripples rising
          const time = Date.now() * 0.002;
          ctx.strokeStyle = `rgba(249, 211, 40, ${Math.abs(Math.sin(time + idx * 2)) * 0.12})`;
          ctx.beginPath();
          ctx.arc(vx, vy, 40 + Math.sin(time) * 10, Math.PI, 0);
          ctx.stroke();
        }
      } else if (chId === 2) {
        // --- Cell Membrane ---
        // Render a soft glowing double membrane lipid bilayer on boundaries
        ctx.strokeStyle = "rgba(46, 252, 158, 0.06)";
        ctx.lineWidth = 12;
        ctx.beginPath();
        const cycle = Date.now() * 0.0005;
        // Big cellular background sphere
        ctx.arc(width * 0.8, height * 0.5, 300 + Math.sin(cycle) * 20, 0, Math.PI * 2);
        ctx.stroke();

        ctx.strokeStyle = "rgba(46, 252, 158, 0.03)";
        ctx.lineWidth = 40;
        ctx.beginPath();
        ctx.arc(width * 0.8, height * 0.5, 300 + Math.sin(cycle) * 20, 0, Math.PI * 2);
        ctx.stroke();
      } else if (chId === 3 || chId === 4) {
        // --- DNA Double Helix Rotating Background ---
        angle3D += 0.003;
        const helixX = width * 0.82;
        const helixY = height * 0.5;
        const scale = 2.5;

        ctx.lineWidth = 2;
        for (let j = -12; j <= 12; j++) {
          const dy = j * 32;
          const theta = angle3D + j * 0.35;
          const x1 = helixX + Math.sin(theta) * 75 * scale;
          const x2 = helixX - Math.sin(theta) * 75 * scale;
          const ptY = helixY + dy;

          // Connect ladder rung
          ctx.strokeStyle = `rgba(0, 240, 255, ${0.15 + Math.cos(theta) * 0.06})`;
          ctx.beginPath();
          ctx.moveTo(x1, ptY);
          ctx.lineTo(x2, ptY);
          ctx.stroke();

          // Left Nitrogenous base sphere
          ctx.fillStyle = `rgba(0, 240, 255, ${0.4 + Math.cos(theta) * 0.3})`;
          ctx.beginPath();
          ctx.arc(x1, ptY, 5 + Math.cos(theta) * 2, 0, Math.PI * 2);
          ctx.fill();

          // Right base sphere
          ctx.fillStyle = `rgba(189, 52, 254, ${0.4 - Math.cos(theta) * 0.3})`;
          ctx.beginPath();
          ctx.arc(x2, ptY, 5 - Math.cos(theta) * 2, 0, Math.PI * 2);
          ctx.fill();
        }
      } else if (chId === 5) {
        // --- Protein folding structures ---
        angle3D += 0.005;
        ctx.save();
        ctx.translate(width * 0.78, height * 0.5);
        ctx.strokeStyle = "rgba(249, 217, 73, 0.15)";
        ctx.lineWidth = 1.5;

        // Project nodes
        const projected = structureNodesArgs.map((node) => {
          // Rotations
          const radY = angle3D;
          const radX = angle3D * 0.5;

          // Coordinate transform
          let x = node.x * Math.cos(radY) - node.z * Math.sin(radY);
          let z = node.x * Math.sin(radY) + node.z * Math.cos(radY);
          let y = node.y * Math.cos(radX) - z * Math.sin(radX);

          // Perspective scaling
          const f = 250 / (250 + z);
          return { x: x * f, y: y * f, size: 5 * f, alpha: (250 - z) / 400 };
        });

        // Draw connections
        ctx.beginPath();
        projected.forEach((p, idx) => {
          if (idx === 0) ctx.moveTo(p.x, p.y);
          else ctx.lineTo(p.x, p.y);
        });
        ctx.stroke();

        // Draw node points
        projected.forEach((p) => {
          ctx.beginPath();
          ctx.fillStyle = `rgba(249, 217, 73, ${Math.max(0.1, p.alpha * 0.8)})`;
          ctx.shadowColor = "#f9d949";
          ctx.shadowBlur = 8;
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
        });
        ctx.restore();
      } else if (chId === 6) {
        // --- Evolution Tree Light Rays ---
        ctx.lineWidth = 1;
        const time = Date.now() * 0.0015;
        for (let r = 0; r < 5; r++) {
          const rx = width * (0.6 + r * 0.08) + Math.sin(time + r) * 15;
          ctx.strokeStyle = `rgba(46, 252, 158, ${0.05 + Math.sin(time + r * 1.5) * 0.03})`;
          ctx.beginPath();
          ctx.moveTo(rx, 0);
          ctx.lineTo(rx - 80, height);
          ctx.stroke();
        }
      } else if (chId === 7) {
        // --- Human Biology Heart Pulse ---
        const time = Date.now() * 0.004;
        const baseline = height * 0.45;
        ctx.strokeStyle = "rgba(0, 240, 255, 0.08)";
        ctx.lineWidth = 3;
        ctx.beginPath();
        for (let sx = 0; sx < width * 0.6; sx += 4) {
          // Normal brain/heart signal flat, spikes around screen center-right
          const centerFactor = Math.max(0, 1 - Math.abs(sx - width * 0.3) / 250);
          let pulse = Math.sin(sx * 0.008 - time) * 10;
          if (centerFactor > 0) {
            // Heart beats spikes
            const spikeCycle = time % (Math.PI * 2);
            let sVal = 0;
            if (spikeCycle < 1.0) {
              sVal = Math.sin(spikeCycle * Math.PI) * 120 * Math.sin(sx * 0.15);
            }
            pulse += sVal * centerFactor;
          }
          if (sx === 0) ctx.moveTo(sx, baseline + pulse);
          else ctx.lineTo(sx, baseline + pulse);
        }
        ctx.stroke();
      } else if (chId === 8) {
        // --- Disease Floating threat cells ---
        const time = Date.now() * 0.001;
        ctx.fillStyle = "rgba(189, 52, 254, 0.04)";
        ctx.strokeStyle = "rgba(189, 52, 254, 0.15)";
        ctx.lineWidth = 1.5;

        // Big viral invaders
        for (let v = 0; v < 3; v++) {
          const vx = width * 0.75 + Math.sin(time + v * 3) * 30;
          const vy = height * 0.3 + v * height * 0.2 + Math.cos(time + v * 3.7) * 20;
          const size = 35 - v * 5;

          // Draw virus nucleus
          ctx.beginPath();
          ctx.arc(vx, vy, size, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();

          // Spikes
          for (let s = 0; s < 12; s++) {
            const sAngle = (s / 12) * Math.PI * 2 + time * 0.2;
            const sx1 = vx + Math.cos(sAngle) * size;
            const sy1 = vy + Math.sin(sAngle) * size;
            const sx2 = vx + Math.cos(sAngle) * (size + 14);
            const sy2 = vy + Math.sin(sAngle) * (size + 14);

            ctx.beginPath();
            ctx.moveTo(sx1, sy1);
            ctx.lineTo(sx2, sy2);
            ctx.stroke();

            // Spike heads
            ctx.beginPath();
            ctx.arc(sx2, sy2, 3, 0, Math.PI * 2);
            ctx.fillStyle = "rgba(189, 52, 254, 0.4)";
            ctx.fill();
          }
        }
      } else if (chId === 9) {
        // --- AI Digital Neural Network Bridge ---
        ctx.strokeStyle = "rgba(0, 240, 255, 0.08)";
        ctx.lineWidth = 1;
        const time = Date.now() * 0.002;
        const nodesLeftX = width * 0.65;
        const nodesRightX = width * 0.9;

        const leftNodesY = [height * 0.22, height * 0.36, height * 0.5, height * 0.64, height * 0.78];
        const rightNodesY = [height * 0.18, height * 0.34, height * 0.5, height * 0.66, height * 0.82];

        // Draw linkages
        leftNodesY.forEach((ly) => {
          rightNodesY.forEach((ry) => {
            const pulseIntensity = Math.abs(Math.sin((ly + ry + time) * 0.015)) * 0.16;
            ctx.strokeStyle = `rgba(0, 240, 255, ${0.03 + pulseIntensity})`;
            ctx.beginPath();
            ctx.moveTo(nodesLeftX, ly);
            ctx.lineTo(nodesRightX, ry);
            ctx.stroke();
          });
        });

        // Draw left nodes (organic neurons)
        leftNodesY.forEach((ly, index) => {
          ctx.fillStyle = "rgba(189, 52, 254, 0.5)";
          ctx.shadowBlur = 10;
          ctx.shadowColor = "#bd34fe";
          ctx.beginPath();
          ctx.arc(nodesLeftX, ly, 6 + Math.sin(time + index) * 2, 0, Math.PI * 2);
          ctx.fill();
        });

        // Draw right nodes (digital neurons)
        rightNodesY.forEach((ry, index) => {
          ctx.fillStyle = "rgba(0, 240, 255, 0.5)";
          ctx.shadowBlur = 10;
          ctx.shadowColor = "#00f0ff";
          ctx.beginPath();
          ctx.arc(nodesRightX, ry, 6 + Math.cos(time + index) * 2, 0, Math.PI * 2);
          ctx.fill();
        });
        ctx.shadowBlur = 0; // reset
      } else if (chId === 10) {
        // --- Future Cosmic Biosynthesis ---
        // Star space grid shifting towards infinity
        const time = Date.now() * 0.0003;
        ctx.strokeStyle = "rgba(46, 252, 158, 0.04)";
        ctx.lineWidth = 1;

        const gridInterval = 80;
        const gridOffset = (time * 50) % gridInterval;

        for (let gridX = gridOffset; gridX < width; gridX += gridInterval) {
          ctx.beginPath();
          ctx.moveTo(gridX, 0);
          ctx.lineTo(gridX, height);
          ctx.stroke();
        }
        for (let gridY = gridOffset; gridY < height; gridY += gridInterval) {
          ctx.beginPath();
          ctx.moveTo(0, gridY);
          ctx.lineTo(width, gridY);
          ctx.stroke();
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("resize", handleResize);
      window.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseleave", handleMouseLeave);
    };
  }, []);

  return (
    <canvas
      id="helixnova-cosmos-canvas"
      ref={canvasRef}
      className="fixed inset-0 w-full h-full object-cover select-none pointer-events-none z-0"
      style={{ mixBlendMode: "screen" }}
    />
  );
}
