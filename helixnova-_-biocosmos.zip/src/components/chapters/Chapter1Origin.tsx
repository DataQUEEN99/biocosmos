import React, { useState } from "react";
import { Chapter } from "../../types";
import { Sparkles, Activity, FlaskConical, Atom } from "lucide-react";

interface ChapterProps {
  chapter: Chapter;
}

interface Molecule {
  id: number;
  name: string;
  chemical: string;
  x: number;
  y: number;
  type: "simple" | "complex";
}

export default function Chapter1Origin({ chapter }: ChapterProps) {
  const [catalystLevel, setCatalystLevel] = useState(50);
  const [synthesized, setSynthesized] = useState<Molecule[]>([]);
  const [synthesizedCount, setSynthesizedCount] = useState(0);

  const compounds = [
    { name: "Ammonia", formula: "NH₃", type: "simple" },
    { name: "Methane", formula: "CH₄", type: "simple" },
    { name: "Hydrogen", formula: "H₂", type: "simple" },
    { name: "Water Vapor", formula: "H₂O", type: "simple" },
  ];

  const handleSynthesize = (compoundFormula: string, name: string) => {
    // Spawn organic molecular outputs
    const newMolecule: Molecule = {
      id: Date.now(),
      name: `Prebiotic ${name}`,
      chemical: compoundFormula,
      x: 30 + Math.random() * 40,
      y: 20 + Math.random() * 50,
      type: "simple",
    };

    setSynthesized((prev) => [newMolecule, ...prev.slice(0, 5)]);
    setSynthesizedCount((prev) => prev + 1);

    // If counts trigger milestone, synthesize complex RNA base pairs
    if (synthesizedCount > 0 && (synthesizedCount + 1) % 4 === 0) {
      setTimeout(() => {
        const complexMolecule: Molecule = {
          id: Date.now() + 1,
          name: "Structured Adenine Purine Ring",
          chemical: "C₅H₅N₅",
          x: 50,
          y: 45,
          type: "complex",
        };
        setSynthesized((prev) => [complexMolecule, ...prev]);
      }, 600);
    }
  };

  const clearSandbox = () => {
    setSynthesized([]);
    setSynthesizedCount(0);
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-xl md:max-w-2xl px-2">
      <div className="flex items-center gap-2 font-mono text-[11px] text-gold-glow uppercase tracking-widest leading-none">
        <FlaskConical className="w-4 h-4" />
        <span>Prebiotic Hydrothermal Reactor</span>
      </div>

      <h3 className="text-xl md:text-2xl font-serif text-white leading-tight">
        Convene Catalytic Metals to Forge the First RNA
      </h3>

      <p className="text-sm text-white/70 leading-relaxed font-sans">
        Porous iron-sulfur walls create physical chambers, shielding fragile prebiotic bonds. Adjust hydrothermal energy pressures and select starting chemical precursors to observe nucleotide emergence.
      </p>

      {/* Synthesis Workspace panel */}
      <div className="glass-panel p-5 rounded-2xl border border-gold-glow/20 flex flex-col gap-4 relative overflow-hidden bg-gradient-to-br from-black/60 to-gold-glow/5">
        <div className="flex items-center justify-between border-b border-white/5 pb-3">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-gold-glow animate-ping" />
            <span className="font-mono text-xs text-white/50">VENT REACTOR TEMPERATURE:</span>
            <span className="font-mono font-bold text-gold-glow">{catalystLevel * 7.5}°C</span>
          </div>
          <button
            onClick={clearSandbox}
            className="text-[10px] font-mono text-white/30 hover:text-white transition-colors cursor-pointer"
          >
            RESET FIELD
          </button>
        </div>

        {/* 2D Chemical Grid stage */}
        <div className="relative h-48 bg-black/50 border border-white/5 rounded-xl flex items-center justify-center overflow-hidden">
          {/* Hydrothermal vent column projection */}
          <div className="absolute inset-x-0 bottom-0 top-1/2 bg-gradient-to-t from-gold-glow/15 via-gold-glow/5 to-transparent blur-md" />

          {synthesized.length === 0 ? (
            <div className="text-center z-10 p-4">
              <Atom className="w-8 h-8 text-white/20 mx-auto mb-2 animate-spin" style={{ animationDuration: "20s" }} />
              <p className="text-xs text-white/40 font-mono">REACTOR IDLE. SELECT CHEMICAL PRECURSORS TO INJECT MATRIX...</p>
            </div>
          ) : (
            <div className="absolute inset-0">
              {synthesized.map((mol) => {
                const isComplex = mol.type === "complex";
                return (
                  <div
                    key={mol.id}
                    className={`absolute rounded-full px-3 py-1.5 flex flex-col items-center justify-center border transition-all duration-700 select-none animate-bounce ${
                      isComplex
                        ? "bg-gold-glow/20 border-gold-glow text-gold-glow shadow-[0_0_15px_rgba(249,217,73,0.3)] Scale-110 z-20"
                        : "bg-white/5 border-white/20 text-white"
                    }`}
                    style={{
                      left: `${mol.x}%`,
                      top: `${mol.y}%`,
                      transform: "translate(-50%, -50%)",
                      animationDuration: isComplex ? "4s" : "6s",
                    }}
                  >
                    <span className="font-mono font-bold text-[10px] tracking-wide">{mol.chemical}</span>
                    <span className="text-[8px] font-mono opacity-60 leading-none">{mol.name}</span>
                  </div>
                );
              })}
            </div>
          )}

          {/* Micro structural heat particle waves */}
          <div className="absolute bottom-2 right-4 flex items-center gap-1">
            <span className="w-1 h-3 bg-gold-glow/30 rounded-full animate-pulse" />
            <span className="w-1 h-5 bg-gold-glow/50 rounded-full animate-pulse" style={{ animationDelay: "0.2s" }} />
            <span className="w-1 h-2 bg-gold-glow/20 rounded-full animate-pulse" style={{ animationDelay: "0.4s" }} />
          </div>
        </div>

        {/* Input Parameters Controls */}
        <div className="flex flex-col gap-3 font-mono text-xs">
          <div className="flex items-center justify-between">
            <span className="text-white/40">CATALYTIC PRESSURE RATIO:</span>
            <span className="text-white font-bold">{catalystLevel} GPa</span>
          </div>
          <input
            type="range"
            min="10"
            max="100"
            value={catalystLevel}
            onChange={(e) => setCatalystLevel(parseInt(e.target.value))}
            className="w-full accent-gold-glow h-1 bg-white/10 rounded-lg cursor-pointer"
          />
        </div>

        {/* Compound Selector Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-2">
          {compounds.map((c) => (
            <button
              key={c.name}
              onClick={() => handleSynthesize(c.formula, c.name)}
              className="px-3 py-2.5 rounded-xl bg-white/5 border border-white/10 text-left hover:bg-gold-glow/10 hover:border-gold-glow/40 transition-all duration-300 group hover:-translate-y-0.5 cursor-pointer"
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-white text-xs">{c.formula}</span>
                <span className="w-1.5 h-1.5 rounded-full bg-white/30 group-hover:bg-gold-glow group-hover:animate-ping" />
              </div>
              <p className="text-[9px] font-mono text-white/50 mt-1">{c.name}</p>
            </button>
          ))}
        </div>

        {synthesizedCount >= 4 && (
          <div className="mt-2 p-3 bg-gold-glow/10 border border-gold-glow/30 rounded-xl flex items-center gap-3">
            <Sparkles className="w-5 h-5 text-gold-glow animate-spin" style={{ animationDuration: "12s" }} />
            <div>
              <p className="text-xs font-bold text-white uppercase font-serif">Catalytic Integration Achieved</p>
              <p className="text-[10px] text-white/60 leading-tight">Prebiotic purine complexes merged. Hydrothermal sulfur mineral nodes initiated replication loops.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
