import React, { useState, useEffect } from "react";
import { Chapter } from "../../types";
import { Activity, Heart, Eye, BrainCircuit } from "lucide-react";

interface ChapterProps {
  chapter: Chapter;
}

export default function Chapter7Human({ chapter }: ChapterProps) {
  const [pulseMode, setPulseMode] = useState<"resting" | "aerobic" | "epi">("resting");
  const [synapticSparks, setSynapticSparks] = useState<number[]>([]);

  const pulseRates = {
    resting: { bpm: 62, desc: "Slower rhythmic homeostasis. Vagus nerve firing acetylcholine to curb metabolic overexertion.", tag: "Parasympathetic Domain" },
    aerobic: { bpm: 124, desc: "Oxygenating systemic muscles. Left ventricle driving continuous stroke volume.", tag: "Adrenaline Activation" },
    epi: { bpm: 168, desc: "Acute threat survival response. Supercharged cardiac volume triggering metabolic fat oxidation.", tag: "Epinephrine Flow" }
  };

  // Generate real-time random neural impulses for visual gratification
  useEffect(() => {
    const timer = setInterval(() => {
      setSynapticSparks((prev) => [
        Math.floor(Math.random() * 100),
        ...prev.slice(0, 8)
      ]);
    }, pulseMode === "resting" ? 1200 : pulseMode === "aerobic" ? 600 : 300);

    return () => clearInterval(timer);
  }, [pulseMode]);

  return (
    <div className="flex flex-col gap-6 w-full max-w-xl md:max-w-2xl px-2">
      <div className="flex items-center gap-2 font-mono text-[11px] text-cyan-glow uppercase tracking-widest leading-none">
        <Activity className="w-5 h-5 text-cyan-glow animate-pulse" />
        <span>Autonomic Telemetry Dashboard</span>
      </div>

      <h3 className="text-xl md:text-2xl font-serif text-white leading-tight">
        Synchronize Sympathetic and Autonomic Pulses
      </h3>

      <p className="text-sm text-white/70 leading-relaxed font-sans">
        Observe cardiorespiratory feedback limits. Toggle different emotional-physical stimuli to watch biological rhythms align, with heart rates pacing and neural synapses sparking.
      </p>

      {/* Bio-Telemetry panel */}
      <div className="glass-panel p-5 rounded-2xl border border-cyan-glow/20 flex flex-col gap-4 bg-gradient-to-br from-black/60 to-cyan-glow/5">
        
        {/* BPM readout header */}
        <div className="flex items-center justify-between border-b border-white/5 pb-3">
          <div className="flex items-center gap-2.5">
            <Heart className={`w-6 h-6 text-cyan-glow ${
              pulseMode === "resting" ? "animate-pulse" : "animate-bounce"
            }`} style={{ animationDuration: pulseMode === "resting" ? "1.5s" : pulseMode === "aerobic" ? "0.8s" : "0.4s" }} />
            <div>
              <p className="text-[10px] font-mono text-white/40 leading-none">SYSTEM CARDIAC RATE</p>
              <h4 className="text-xl font-mono font-black text-white">{pulseRates[pulseMode].bpm} <span className="text-xs font-normal text-white/40">BPM</span></h4>
            </div>
          </div>

          <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-cyan-glow/10 text-cyan-glow border border-cyan-glow/20">
            {pulseRates[pulseMode].tag}
          </span>
        </div>

        {/* Pulse waveform description card */}
        <p className="text-xs text-white/70 leading-relaxed font-sans bg-black/40 p-3.5 rounded-xl border border-white/5">
          {pulseRates[pulseMode].desc}
        </p>

        {/* Tactical stim button selects */}
        <div className="grid grid-cols-3 gap-2.5">
          <button
            onClick={() => setPulseMode("resting")}
            className={`p-3 rounded-xl border text-center transition-all duration-300 pointer-events-auto cursor-pointer ${
              pulseMode === "resting"
                ? "bg-cyan-glow/15 border-cyan-glow text-cyan-glow shadow-[0_0_12px_rgba(0,240,255,0.15)]"
                : "bg-white/5 border-white/5 text-white/50 hover:text-white"
            }`}
          >
            <span className="font-bold text-xs block">RESTING</span>
            <span className="text-[8px] font-mono opacity-50">62 BPM</span>
          </button>

          <button
            onClick={() => setPulseMode("aerobic")}
            className={`p-3 rounded-xl border text-center transition-all duration-300 pointer-events-auto cursor-pointer ${
              pulseMode === "aerobic"
                ? "bg-cyan-glow/15 border-cyan-glow text-cyan-glow shadow-[0_0_12px_rgba(0,240,255,0.15)]"
                : "bg-white/5 border-white/5 text-white/50 hover:text-white"
            }`}
          >
            <span className="font-bold text-xs block">AEROBIC</span>
            <span className="text-[8px] font-mono opacity-50">124 BPM</span>
          </button>

          <button
            onClick={() => setPulseMode("epi")}
            className={`p-3 rounded-xl border text-center transition-all duration-300 pointer-events-auto cursor-pointer ${
              pulseMode === "epi"
                ? "bg-cyan-glow/15 border-cyan-glow text-cyan-glow shadow-[0_0_12px_rgba(0,240,255,0.15)]"
                : "bg-white/5 border-white/5 text-white/50 hover:text-white"
            }`}
          >
            <span className="font-bold text-xs block">ADRENALINE</span>
            <span className="text-[8px] font-mono opacity-50">168 BPM</span>
          </button>
        </div>

        {/* Neural synapse sparks monitor */}
        <div className="bg-black/50 p-4 border border-white/5 rounded-xl">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-1.5 font-mono text-[9px] text-[#bd34fe]">
              <BrainCircuit className="w-3.5 h-3.5 animate-spin" style={{ animationDuration: "12s" }} />
              <span>CEREBRAL SPARK EMISSION LOG:</span>
            </div>
            <span className="text-[8px] font-mono text-white/30 uppercase">REAL-TIME</span>
          </div>

          <div className="flex flex-wrap gap-2 min-h-12 items-center">
            {synapticSparks.length === 0 ? (
              <span className="text-[9px] font-mono text-white/30 italic">LISTENING FOR SYNAPTIC ION DISCHARGES...</span>
            ) : (
              synapticSparks.map((spark, idx) => (
                <span
                  key={idx}
                  className="px-2 py-0.5 rounded font-mono text-[9px] bg-cyan-glow/5 border border-cyan-glow/20 text-[#a5f3fc] animate-pulse"
                >
                  SPK_{spark}mV
                </span>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
