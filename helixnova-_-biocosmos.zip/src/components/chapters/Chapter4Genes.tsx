import React, { useState } from "react";
import { Chapter } from "../../types";
import { ToggleLeft, ToggleRight, Sparkles, Binary, Sliders } from "lucide-react";

interface ChapterProps {
  chapter: Chapter;
}

interface LocusMarker {
  id: string;
  chromosome: number;
  name: string;
  scientificMarker: string;
  phenotypeEffect: string;
  activeStatus: boolean;
  glowClass: string;
}

const CHROMOSOME_LOCI: LocusMarker[] = [
  {
    id: "g_opt",
    chromosome: 1,
    name: "Optical Spectral Resolution (OPN1LW)",
    scientificMarker: "Chr 1: q28.14",
    phenotypeEffect: "Expands sensory depth of retinal cones, enabling rich tetrachromatic ultraviolet spectrum comprehension.",
    activeStatus: true,
    glowClass: "text-cyan-glow bg-cyan-glow/10"
  },
  {
    id: "g_lon",
    chromosome: 7,
    name: "Active Lysosomal Autophagy (SIRT6)",
    scientificMarker: "Chr 7: p13.3",
    phenotypeEffect: "Accelerates structural waste clean up inside cytoplasm matrixes, maintaining telomerase length.",
    activeStatus: false,
    glowClass: "text-[#bd34fe] bg-[#bd34fe]/10"
  },
  {
    id: "g_syn",
    chromosome: 11,
    name: "Cerebral Synaptic Plasticity (BDNF)",
    scientificMarker: "Chr 11: p14.1",
    phenotypeEffect: "Triggers dendritic spine remodeling and fast synaptic propagation, amplifying computational adaptation.",
    activeStatus: true,
    glowClass: "text-[#2efc9e] bg-[#2efc9e]/10"
  },
  {
    id: "g_card",
    chromosome: 19,
    name: "Autonomic Cardiac Elasticity (NOS3)",
    scientificMarker: "Chr 19: q13.3",
    phenotypeEffect: "Optimizes capillary nitrous dilatation levels during aerobic stresses, reducing long-term tissue decay.",
    activeStatus: false,
    glowClass: "text-amber-300 bg-amber-500/10"
  }
];

export default function Chapter4Genes({ chapter }: ChapterProps) {
  const [lociSettings, setLociSettings] = useState<LocusMarker[]>(CHROMOSOME_LOCI);

  const toggleLocus = (id: string) => {
    setLociSettings((prev) =>
      prev.map((loc) =>
        loc.id === id ? { ...loc, activeStatus: !loc.activeStatus } : loc
      )
    );
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-xl md:max-w-2xl px-2">
      <div className="flex items-center gap-2 font-mono text-[11px] text-[#bd34fe] uppercase tracking-widest leading-none">
        <Sparkles className="w-4 h-4 text-[#bd34fe] animate-pulse" />
        <span>Chromatin Coordinate Array</span>
      </div>

      <h3 className="text-xl md:text-2xl font-serif text-white leading-tight">
        Activate Loci to Expression Phenotypic Milestones
      </h3>

      <p className="text-sm text-white/70 leading-relaxed font-sans">
        Inside dense chromosome folding frameworks, genes function as active electric hotspots. Activate biological coordinate channels below to observe genomic alignment changes.
      </p>

      {/* Chromosome blueprint map */}
      <div className="glass-panel p-5 rounded-2xl border border-white/5 flex flex-col gap-4 bg-gradient-to-br from-black/60 to-purple-glow/5">
        <div className="flex items-center justify-between border-b border-white/5 pb-3">
          <div className="flex items-center gap-2">
            <span className="font-mono text-xs text-white/50">MUTATIONAL EXPRESSION RATE:</span>
            <span className="font-mono font-bold text-[#bd34fe]">
              {Math.round((lociSettings.filter(l => l.activeStatus).length / 4) * 100)}% ACTIVE
            </span>
          </div>
          <Binary className="w-4 h-4 text-white/30 animate-pulse" />
        </div>

        {/* Constellation nodes space */}
        <div className="flex flex-col gap-3">
          {lociSettings.map((loc) => (
            <div
              key={loc.id}
              className={`p-3.5 rounded-xl border flex items-center justify-between gap-4 transition-all duration-300 ${
                loc.activeStatus
                  ? "bg-white/5 border-white/10 shadow-[0_0_12px_rgba(255,255,255,0.03)]"
                  : "bg-black/30 border-dashed border-white/5 opacity-55"
              }`}
            >
              <div className="flex-1">
                <div className="flex items-center gap-2.5">
                  <span className={`px-2 py-0.5 rounded text-[8px] font-mono font-black ${loc.glowClass}`}>
                    {loc.scientificMarker}
                  </span>
                  <span className="text-xs font-bold font-sans text-white uppercase tracking-wider">
                    {loc.name}
                  </span>
                </div>
                <p className="text-[10px] text-white/60 leading-normal mt-1.5 font-sans">
                  {loc.phenotypeEffect}
                </p>
              </div>

              {/* Toggle switch Button */}
              <button
                onClick={() => toggleLocus(loc.id)}
                className="text-white/80 hover:text-white hover:scale-105 transition-all p-1 cursor-pointer"
              >
                {loc.activeStatus ? (
                  <ToggleRight className="w-8 h-8 text-[#2efc9e]" />
                ) : (
                  <ToggleLeft className="w-8 h-8 text-white/20" />
                )}
              </button>
            </div>
          ))}
        </div>

        {/* Mini status report bar */}
        <div className="mt-2 p-3 bg-white/5 border border-white/5 rounded-xl flex items-center gap-2.5">
          <Sliders className="w-4 h-4 text-white/40" />
          <p className="text-[9px] font-mono text-white/40 uppercase">
            PHENOTYPE INDEX: INITIATING MULTI-MARKER STABILIZATION METADATA...
          </p>
        </div>
      </div>
    </div>
  );
}
