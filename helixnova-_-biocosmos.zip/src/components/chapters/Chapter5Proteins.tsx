import React, { useState } from "react";
import { Chapter } from "../../types";
import { Sliders, RefreshCw, Layers, Award } from "lucide-react";

interface ChapterProps {
  chapter: Chapter;
}

export default function Chapter5Proteins({ chapter }: ChapterProps) {
  const [hydrophobicAttraction, setHydrophobicAttraction] = useState(60);
  const [thermalEnergy, setThermalEnergy] = useState(40);
  const [chainLength, setChainLength] = useState(12);

  // Determine if folded into a stable configuration (e.g. high attraction and low thermal keeps it perfectly locked)
  const isStableFolded = hydrophobicAttraction >= 75 && thermalEnergy < 45;
  const isDenatured = thermalEnergy >= 85;

  return (
    <div className="flex flex-col gap-6 w-full max-w-xl md:max-w-2xl px-2">
      <div className="flex items-center gap-2 font-mono text-[11px] text-gold-glow uppercase tracking-widest leading-none">
        <Layers className="w-4 h-4 text-gold-glow" />
        <span>Thermodynamic Folding Field</span>
      </div>

      <h3 className="text-xl md:text-2xl font-serif text-white leading-tight">
        Simulate Ribosome Polypeptide Folding Limits
      </h3>

      <p className="text-sm text-white/70 leading-relaxed font-sans">
        Unlike inert codes, proteins function exclusively via physical geometry. Adjust polar hydrophobic alignments and manage temperature settings to lock the protein into its ground energy state.
      </p>

      {/* Folding Playground */}
      <div className="glass-panel p-5 rounded-2xl border border-gold-glow/20 flex flex-col gap-4 bg-gradient-to-br from-black/60 to-gold-glow/5">
        <div className="flex items-center justify-between border-b border-white/5 pb-3">
          <div className="flex items-center gap-2">
            <span className="font-mono text-xs text-white/50">FOLDING STATUS:</span>
            <span className={`font-mono font-black text-xs px-2 py-0.5 rounded ${
              isDenatured
                ? "bg-red-500/10 text-red-400"
                : isStableFolded
                ? "bg-emerald-500/10 text-emerald-glow"
                : "bg-white/5 text-white/60 animate-pulse"
            }`}>
              {isDenatured ? "DENATURED (CHAOTIC STRING)" : isStableFolded ? "STABLE ALPHA-GEODESIC BLOCK" : "RANDOM INTRAMOLECULAR COIL"}
            </span>
          </div>
          <button
            onClick={() => {
              setHydrophobicAttraction(60);
              setThermalEnergy(40);
              setChainLength(12);
            }}
            className="text-[10px] font-mono text-white/30 hover:text-white transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <RefreshCw className="w-3 h-3" />
            RESET PHYSICS
          </button>
        </div>

        {/* Polypeptide SVG structural renderer */}
        <div className="relative h-44 bg-black/50 border border-white/5 rounded-xl flex items-center justify-center overflow-hidden">
          <svg className="w-full h-full p-4" viewBox="0 0 400 150">
            {/* Generate reactive node lines */}
            <path
              d={(() => {
                let dStr = "M 50 75";
                const steps = chainLength;
                
                // Adjust curve amplitude depending on folding state
                const attractionMult = hydrophobicAttraction / 100;
                const heatMult = thermalEnergy / 100;

                for (let i = 1; i <= steps; i++) {
                  const segX = 50 + (i * (300 / steps));
                  
                  // Compute dynamic structural offsets based on physics values
                  let segY = 75;
                  if (isDenatured) {
                    // Wild random chaotic vibration
                    segY = 75 + Math.sin(i * 1.8) * 15 * (1 + heatMult);
                  } else if (isStableFolded) {
                    // Highly structured alpha helix coil sequence
                    segY = 75 + Math.sin(i * 2.5) * 35 * (1 - attractionMult * 0.1);
                  } else {
                    // Soft intermediate random loop
                    segY = 75 + Math.cos(i * 1.2) * 20 * (0.8 + heatMult * 0.4);
                  }
                  
                  dStr += ` Q ${segX - (150/steps)} ${segY + 15} ${segX} ${segY}`;
                }
                return dStr;
              })()}
              fill="none"
              stroke={isStableFolded ? "#2efc9e" : isDenatured ? "#f43f5e" : "#f9d949"}
              strokeWidth={4}
              strokeLinecap="round"
              className="transition-all duration-700 ease-out"
            />

            {/* Render Amino Acid node circles along the path */}
            {Array.from({ length: chainLength }).map((_, index) => {
              const attractionMult = hydrophobicAttraction / 100;
              const heatMult = thermalEnergy / 100;
              const steps = chainLength;
              const xCoord = 50 + (index * (300 / steps));
              
              let yCoord = 75;
              if (isDenatured) {
                yCoord = 75 + Math.sin(index * 1.8) * 15 * (1 + heatMult);
              } else if (isStableFolded) {
                yCoord = 75 + Math.sin(index * 2.5) * 35 * (1 - attractionMult * 0.1);
              } else {
                yCoord = 75 + Math.cos(index * 1.2) * 20 * (0.8 + heatMult * 0.4);
              }

              return (
                <circle
                  key={index}
                  cx={xCoord}
                  cy={yCoord}
                  r={index % 2 === 0 ? "7" : "5"}
                  fill={isStableFolded ? "#00f0ff" : isDenatured ? "#ef4444" : "#f9d949"}
                  className="transition-all duration-700 ease-out"
                  stroke="#ffffff"
                  strokeWidth={1}
                />
              );
            })}
          </svg>

          {/* Micro thermal atmospheric dust dots */}
          <div className="absolute inset-0 pointer-events-none overflow-hidden">
            <div className={`absolute w-full h-full bg-red-500/5 transition-opacity duration-300 ${
              isDenatured ? "opacity-100" : "opacity-0"
            }`} />
          </div>
        </div>

        {/* Sliders Container */}
        <div className="flex flex-col gap-4 font-mono text-xs">
          
          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between">
              <span className="text-white/40">HYDROPHOBIC ATTRACTION COEFFICIENT:</span>
              <span className="text-white font-bold">{hydrophobicAttraction}% STRONG FORCE</span>
            </div>
            <input
              type="range"
              min="20"
              max="100"
              value={hydrophobicAttraction}
              onChange={(e) => setHydrophobicAttraction(parseInt(e.target.value))}
              className="w-full accent-gold-glow h-1 bg-white/10 rounded-lg cursor-pointer"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between">
              <span className="text-white/40">AMBIENT THERMAL MOTION:</span>
              <span className="text-white font-bold">{thermalEnergy}°K THERMAL SPARK</span>
            </div>
            <input
              type="range"
              min="10"
              max="100"
              value={thermalEnergy}
              onChange={(e) => setThermalEnergy(parseInt(e.target.value))}
              className="w-full accent-gold-glow h-1 bg-white/10 rounded-lg cursor-pointer"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between">
              <span className="text-white/40">PRIMARY POLYPEPTIDE RESIDUES:</span>
              <span className="text-white font-bold">{chainLength} MONOMERS</span>
            </div>
            <input
              type="range"
              min="6"
              max="20"
              value={chainLength}
              onChange={(e) => setChainLength(parseInt(e.target.value))}
              className="w-full accent-gold-glow h-1 bg-white/10 rounded-lg cursor-pointer"
            />
          </div>

        </div>

        {/* Stable folded state awards notification trigger */}
        {isStableFolded && (
          <div className="mt-3 p-4 bg-emerald-500/10 border border-emerald-400/30 rounded-2xl flex items-center gap-3.5 animate-pulse">
            <Award className="w-6 h-6 text-emerald-glow" />
            <div>
              <p className="text-xs font-bold text-white uppercase font-sans tracking-wide">
                Optimal Enzymatic State Achieved
              </p>
              <p className="text-[10px] text-white/60 leading-normal">
                Van der Waals polar chains and hydrophobic pockets aligned flawlessly. Thermodynamic delta energy minimized, achieving active catalytic properties.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
