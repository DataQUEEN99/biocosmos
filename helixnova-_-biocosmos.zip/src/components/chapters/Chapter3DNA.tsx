import React, { useState } from "react";
import { Chapter } from "../../types";
import { Check, ShieldCheck, RefreshCw, Dna } from "lucide-react";

interface ChapterProps {
  chapter: Chapter;
}

interface BasePair {
  label: string;
  partner: string;
  name: string;
  color: string;
}

const NUCLEOBASES: BasePair[] = [
  { label: "A", partner: "T", name: "Adenine", color: "bg-cyan-500 text-black border-cyan-400" },
  { label: "T", partner: "A", name: "Thymine", color: "bg-[#bd34fe]/40 text-[#f3f4f6] border-[#bd34fe]" },
  { label: "G", partner: "C", name: "Guanine", color: "bg-emerald-500/40 text-[#f3f4f6] border-emerald-400" },
  { label: "C", partner: "G", name: "Cytosine", color: "bg-gold-glow text-black border-gold-glow" },
];

export default function Chapter3DNA({ chapter }: ChapterProps) {
  const [activeNucleotides, setActiveNucleotides] = useState<string[]>(["A", "G", "T"]);
  const [matchedPairs, setMatchedPairs] = useState<Array<{ left: string; right: string; status: "success" | "pending" }>>([
    { left: "A", right: "T", status: "success" },
    { left: "G", right: "C", status: "success" },
    { left: "T", right: "A", status: "success" },
  ]);
  const [selectedBase, setSelectedBase] = useState<BasePair | null>(null);
  const [successCount, setSuccessCount] = useState(3);

  // Provide next nucleotide constraint to guide pairing
  const currentChallengeBase = NUCLEOBASES[matchedPairs.length % 4];

  const handleBaseMatch = (testBase: BasePair) => {
    // If the selected test base correctly matches the partner of current challenge base
    if (testBase.label === currentChallengeBase.partner) {
      // Valid matching base pair
      const newPair = {
        left: currentChallengeBase.label,
        right: testBase.label,
        status: "success" as const,
      };

      setMatchedPairs((prev) => [...prev, newPair]);
      setSuccessCount((prev) => prev + 1);
      setSelectedBase(null);
    } else {
      // Invalid
      setSelectedBase(testBase);
      setTimeout(() => setSelectedBase(null), 1000);
    }
  };

  const handleReset = () => {
    setMatchedPairs([
      { left: "A", right: "T", status: "success" },
      { left: "G", right: "C", status: "success" },
      { left: "T", right: "A", status: "success" },
    ]);
    setSuccessCount(3);
    setSelectedBase(null);
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-xl md:max-w-2xl px-2">
      <div className="flex items-center gap-2 font-mono text-[11px] text-cyan-glow uppercase tracking-widest leading-none">
        <Dna className="w-5 h-5 text-cyan-glow" />
        <span>Helical Transcription Sequencer</span>
      </div>

      <h3 className="text-xl md:text-2xl font-serif text-white leading-tight">
        Synthesize Organic Codons via Nitrogenous Pairing
      </h3>

      <p className="text-sm text-white/70 leading-relaxed font-sans">
        Double strands split during cellular transcription, presenting active templates. Click the corresponding partner base to secure hydrogen bonds and assemble healthy genetic instructions.
      </p>

      {/* DNA Pairing Console */}
      <div className="glass-panel p-5 rounded-2xl border border-cyan-glow/20 flex flex-col gap-4 bg-gradient-to-br from-black/60 to-cyan-glow/5">
        <div className="flex items-center justify-between border-b border-white/5 pb-3">
          <div className="flex items-center gap-2">
            <span className="font-mono text-xs text-white/50">TRANSCRIPTION STABILITY:</span>
            <span className="font-mono font-bold text-cyan-glow">
              {Math.min(100, Math.round((successCount / 8) * 100))}% NOMINAL
            </span>
          </div>
          <button
            onClick={handleReset}
            className="flex items-center gap-1.5 text-[10px] font-mono text-white/30 hover:text-white transition-colors cursor-pointer"
          >
            <RefreshCw className="w-3 h-3" />
            RESTART SEQUENCE
          </button>
        </div>

        {/* Dynamic vertical strand list */}
        <div className="space-y-2 bg-gradient-to-b from-black/20 to-black/60 p-4 border border-white/5 rounded-xl min-h-[170px] flex flex-col justify-end">
          {matchedPairs.map((pair, idx) => (
            <div key={idx} className="flex items-center justify-center gap-6 md:gap-10">
              {/* Left Template strand */}
              <div className="flex items-center justify-end w-24">
                <span className="font-mono text-[10px] text-white/40 mr-2 uppercase">CH_0{idx + 1}</span>
                <span className="w-7 h-7 rounded-md flex items-center justify-center font-bold bg-white/5 text-cyan-glow border border-cyan-glow/20 text-xs">
                  {pair.left}
                </span>
              </div>

              {/* Hydrogen Bonds Connecting Line */}
              <div className="flex-1 relative h-[2px] bg-gradient-to-r from-cyan-glow/40 to-[#bd34fe]/40 flex items-center justify-center">
                <span className="absolute w-2 h-2 rounded-full bg-white z-10 animate-ping" />
                <span className="font-mono text-[8px] text-white/30 bg-black/90 px-1 absolute top-[-7px] uppercase tracking-tighter">
                  H-BOND
                </span>
              </div>

              {/* Partner strand */}
              <div className="flex items-center w-24">
                <span className="w-7 h-7 rounded-md flex items-center justify-center font-bold text-xs bg-[#bd34fe]/25 border border-[#bd34fe]/40 text-[#f3f4f6]">
                  {pair.right}
                </span>
                <Check className="w-4 h-4 text-emerald-glow ml-2 opacity-80" />
              </div>
            </div>
          ))}

          {/* Active Challanger Node row */}
          {matchedPairs.length < 8 && (
            <div className="flex items-center justify-center gap-6 md:gap-10 mt-3 p-2 bg-white/5 border border-dashed border-cyan-glow/30 rounded-xl animate-pulse">
              <div className="flex items-center justify-end w-24">
                <span className="font-mono text-[9px] text-[#00f0ff] mr-2">TEMPLATE:</span>
                <span className="w-8 h-8 rounded-lg flex items-center justify-center font-black bg-cyan-glow/20 text-cyan-glow text-sm border-2 border-cyan-glow">
                  {currentChallengeBase.label}
                </span>
              </div>

              <div className="flex-1 h-[2px] bg-white/10" />

              <div className="flex items-center w-24 justify-start">
                <span className="w-8 h-8 rounded-lg flex items-center justify-center font-black text-sm bg-white/5 text-white/40 border border-white/15">
                  ?
                </span>
                <span className="text-[9px] font-mono text-[#bd34fe] ml-2 uppercase animate-bounce">PAIR ME</span>
              </div>
            </div>
          )}
        </div>

        {/* Nucleotide inputs selection container */}
        {matchedPairs.length < 8 ? (
          <div className="mt-2 text-center">
            <p className="text-[10px] font-mono text-white/40 mb-3 uppercase tracking-wider">
              INJECT HYDROGEN-BOND POLARITY FOR:{" "}
              <span className="text-white font-bold">{currentChallengeBase.name}</span> (Requires partner:{" "}
              <span className="text-cyan-glow font-black">{currentChallengeBase.partner}</span>)
            </p>
            <div className="grid grid-cols-4 gap-2.5">
              {NUCLEOBASES.map((nucleo) => {
                const isActiveIncorrect = selectedBase?.label === nucleo.label;
                return (
                  <button
                    key={nucleo.label}
                    onClick={() => handleBaseMatch(nucleo)}
                    className={`p-3 rounded-xl border text-center font-mono font-black text-sm transition-all duration-300 transform hover:-translate-y-0.5 cursor-pointer ${
                      isActiveIncorrect
                        ? "bg-red-500/25 border-red-500 text-red-100 shake"
                        : "bg-white/5 border-white/10 hover:bg-white/10 text-white"
                    }`}
                  >
                    <div>{nucleo.label}</div>
                    <span className="text-[8px] opacity-40 block font-normal mt-0.5">{nucleo.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="mt-3 p-4 bg-cyan-glow/10 border border-cyan-glow/30 rounded-2xl flex items-center gap-3.5 animate-pulse">
            <ShieldCheck className="w-6 h-6 text-cyan-glow" />
            <div>
              <p className="text-xs font-bold text-white uppercase font-sans tracking-wide">
                DNA CODON SYSTEM IMMUTABLE
              </p>
              <p className="text-[10px] text-white/60 leading-normal">
                Helical transcription verified. Structural base matching succeeded without matching error codes. Codon set transcribed to local messenger-RNA streams.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
