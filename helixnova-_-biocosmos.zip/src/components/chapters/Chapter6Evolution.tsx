import React, { useState } from "react";
import { Chapter } from "../../types";
import { GitBranch, Compass, RefreshCw, Layers } from "lucide-react";

interface ChapterProps {
  chapter: Chapter;
}

interface EvolutionNode {
  id: string;
  name: string;
  epoch: string;
  speciationKey: string;
  extinctionPressure: string;
  morphologyDesc: string;
  anatomicalUpgrade: string;
}

const PHYLOGENY_TREE: EvolutionNode[] = [
  {
    id: "archean",
    name: "Archean Stromatolites",
    epoch: "3.5 Billion Years Ago",
    speciationKey: "Oxygenic Photosynthesis",
    extinctionPressure: "Anaerobic UV Radiation",
    morphologyDesc: "Cyanobacterial colony mats secreting calcium carbonate, converting toxic iron-rich seas into oxygenated atmospheres.",
    anatomicalUpgrade: "Photosynthetic electron chains"
  },
  {
    id: "cambrian",
    name: "Cambrian Morphologies",
    epoch: "530 Million Years Ago",
    speciationKey: "Hard Exoskeletons & Eyes",
    extinctionPressure: "Benthic Predation expansion",
    morphologyDesc: "Explosive radiation of hard calcite shells, visual sensory nodes (compound lenses), and segment appendages.",
    anatomicalUpgrade: "Tripartite nervous system & eyes"
  },
  {
    id: "devonian",
    name: "Devonian Lungfish (Tiktaalik)",
    epoch: "375 Million Years Ago",
    speciationKey: "Tetrapod Terrestrial Girdles",
    extinctionPressure: "Hypoxic Shallow Lagoons",
    morphologyDesc: "Shallow delta species evolving muscular pectoral joints and dual air-sac atmospheric gas exchange to walk mudbanks.",
    anatomicalUpgrade: "Lungs & articulating wrists"
  },
  {
    id: "cretaceous",
    name: "Therapsids & Mammaliaforms",
    epoch: "110 Million Years Ago",
    speciationKey: "Endothermic Thermoregulation",
    extinctionPressure: "Cretaceous Impact winter",
    morphologyDesc: "Nocturnal, insect-hunting species developing warm insulating fur, milk secretion glands, and complex auditory inner ears.",
    anatomicalUpgrade: "Neocortex foundation & hearing"
  },
  {
    id: "modern",
    name: "Anthropoid Cephalization",
    epoch: "200,000 Years Ago - Present",
    speciationKey: "Cognitive Symbolic Linguism",
    extinctionPressure: "Toba Volcanic Freeze",
    morphologyDesc: "Bipedal hominids utilizing opposable thumbs, expanding frontal cortical gray matters, and global abstract tool synthesis.",
    anatomicalUpgrade: "Enlarged prefrontal cortex"
  }
];

export default function Chapter6Evolution({ chapter }: ChapterProps) {
  const [activeNode, setActiveNode] = useState<EvolutionNode>(PHYLOGENY_TREE[4]);

  return (
    <div className="flex flex-col gap-6 w-full max-w-xl md:max-w-2xl px-2">
      <div className="flex items-center gap-2 font-mono text-[11px] text-emerald-glow uppercase tracking-widest leading-none">
        <GitBranch className="w-4 h-4 text-emerald-glow animate-pulse" />
        <span>Phylogenetic Speciation Vector</span>
      </div>

      <h3 className="text-xl md:text-2xl font-serif text-white leading-tight">
        Chart Speciation Trajectories Across Extinction Events
      </h3>

      <p className="text-sm text-white/70 leading-relaxed font-sans">
        Adaptation responds to catastrophic climate disruption and continental collisions. Navigate crucial transition points along the biological tree of life below.
      </p>

      {/* Evolution Tree Interface */}
      <div className="glass-panel p-5 rounded-2xl border border-emerald-glow/20 flex flex-col md:flex-row gap-5 bg-gradient-to-br from-black/60 to-emerald-glow/5">
        
        {/* Branch Interactive Tree Map */}
        <div className="w-full md:w-1/2 flex flex-col justify-between">
          <span className="font-mono text-[9px] text-white/40 mb-3 block uppercase tracking-widest">
            EVOLUTIONARY PATHWAY RADIALS
          </span>

          <div className="flex flex-col gap-2.5 relative">
            {/* Background line representing evolutionary timeline progress */}
            <div className="absolute left-[19px] top-6 bottom-6 w-0.5 bg-gradient-to-b from-emerald-glow/30 via-emerald-glow/10 to-[#bd34fe]/10" />

            {PHYLOGENY_TREE.map((node, index) => {
              const isActive = node.id === activeNode.id;
              return (
                <button
                  key={node.id}
                  onClick={() => setActiveNode(node)}
                  className={`flex items-center gap-3.5 p-2 rounded-xl border text-left transition-all duration-300 pointer-events-auto cursor-pointer ${
                    isActive
                      ? "bg-emerald-500/15 border-emerald-400/50 shadow-[0_0_15px_rgba(46,252,158,0.12)] -translate-x-1"
                      : "bg-white/5 border-white/5 hover:bg-white/10"
                  }`}
                >
                  {/* Glowing index bulb */}
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-mono font-bold text-xs border ${
                    isActive
                      ? "bg-emerald-glow text-black border-emerald-glow"
                      : "bg-black/40 text-white/30 border-white/10"
                  }`}>
                    0{index + 1}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white uppercase tracking-wider">{node.name}</h4>
                    <p className="text-[9px] font-mono text-white/40">{node.epoch}</p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected branch description */}
        <div className="w-full md:w-1/2 flex flex-col justify-between border-t md:border-t-0 md:border-l border-white/10 pt-4 md:pt-0 md:pl-5">
          <div className="flex flex-col gap-2.5">
            <span className="font-mono text-[9px] text-emerald-glow/80 uppercase tracking-widest leading-none">
              SPECIATION PROFILE
            </span>
            <h4 className="text-sm font-semibold text-white tracking-wide">
              {activeNode.name}
            </h4>
            <p className="text-[10px] font-mono text-white/40 italic">
              {activeNode.epoch}
            </p>
            <p className="text-xs text-white/75 leading-relaxed font-sans">
              {activeNode.morphologyDesc}
            </p>
          </div>

          <div className="mt-4 flex flex-col gap-2 border-t border-white/5 pt-3">
            <div className="flex items-center justify-between text-[10px] font-mono">
              <span className="text-white/40">EVOLUTIONARY LEAP:</span>
              <span className="text-emerald-glow font-bold uppercase">{activeNode.speciationKey}</span>
            </div>
            <div className="flex items-center justify-between text-[10px] font-mono">
              <span className="text-white/40">SELECTION PRESSURE:</span>
              <span className="text-red-400 font-bold uppercase">{activeNode.extinctionPressure}</span>
            </div>
            <div className="flex items-center justify-between text-[10px] font-mono">
              <span className="text-white/40">ANATOMICAL UPGRADE:</span>
              <span className="text-white font-semibold">{activeNode.anatomicalUpgrade}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
