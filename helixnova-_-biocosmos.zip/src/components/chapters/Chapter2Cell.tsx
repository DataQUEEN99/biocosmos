import React, { useState } from "react";
import { Chapter } from "../../types";
import { Info, Cpu, Zap, Activity } from "lucide-react";

interface ChapterProps {
  chapter: Chapter;
}

interface Organelle {
  id: string;
  name: string;
  scienceName: string;
  functionDesc: string;
  energyOutput: string;
  complexityIndex: string;
  color: string;
}

const ORGANELLES: Organelle[] = [
  {
    id: "nucleus",
    name: "Information Core (Nucleus)",
    scienceName: "Karyoplasm & Chromatin Shield",
    functionDesc: "Encapsulates the helical chromosome blueprint inside a selective double-lipid nuclear envelope, guarding genomic translation instructions from raw cytoplasms.",
    energyOutput: "Minimal Direct ATP",
    complexityIndex: "98/100 Peak",
    color: "from-cyan-400 to-cyan-600"
  },
  {
    id: "mitochondria",
    name: "ATP Synthase Reactor (Mitochondria)",
    scienceName: "Endosymbiotic Power Plant",
    functionDesc: "Originally a free-living bacterial lineage merged 1.8 billion years ago. Pumps protons across folded internal cristae membranes to churn out chemical ATP fuel molecules.",
    energyOutput: "36 Resonating ATP Molecules",
    complexityIndex: "94/100 Core",
    color: "from-emerald-400 to-emerald-600"
  },
  {
    id: "ribosome",
    name: "Structural Printer (Ribosome)",
    scienceName: "Polypeptide Peptide Compiler",
    functionDesc: "Scans active messenger-RNA sequences and links corresponding t-RNA carrying amino acids, physically printing proteins under electromagnetic atomic precision.",
    energyOutput: "2 ATP Spent per Amino Acid Link",
    complexityIndex: "96/100 Assembly",
    color: "from-amber-400 to-amber-600"
  },
  {
    id: "endoplasmic_reticulum",
    name: "Structural Conduit (ER Grid)",
    scienceName: "Chaperone Synthesis Network",
    functionDesc: "An expansive folded folding labyrinth, studded with active printers, that assists physical chaperone protein folding and sorting channels.",
    energyOutput: "Local thermal metabolic heat",
    complexityIndex: "88/100 Sorting",
    color: "from-purple-400 to-purple-600"
  }
];

export default function Chapter2Cell({ chapter }: ChapterProps) {
  const [selectedOrganelle, setSelectedOrganelle] = useState<Organelle>(ORGANELLES[1]);
  const [cellularMetabolicRate, setCellularMetabolicRate] = useState(82);

  return (
    <div className="flex flex-col gap-6 w-full max-w-xl md:max-w-2xl px-2">
      <div className="flex items-center gap-2 font-mono text-[11px] text-emerald-glow uppercase tracking-widest leading-none">
        <Activity className="w-4 h-4 animate-pulse text-emerald-glow" />
        <span>Eukaryotic Microcosmos Diagnostics</span>
      </div>

      <h3 className="text-xl md:text-2xl font-serif text-white leading-tight">
        Traverse the High-Efficiency Cellular Machine
      </h3>

      <p className="text-sm text-white/70 leading-relaxed font-sans">
        Unlike simplistic bacteria, complex eukaryotic cells operate with dedicated organelle chambers—each hosting an ancient evolutionary alliance that supercharged the energetics of multicellular lifecycles.
      </p>

      {/* Interactive Cellular Interface */}
      <div className="glass-panel p-5 rounded-2xl border border-emerald-glow/20 flex flex-col md:flex-row gap-5 bg-gradient-to-br from-black/60 to-emerald-glow/5">
        
        {/* SVG Membrane Interactive Explorer */}
        <div className="w-full md:w-1/2 flex flex-col items-center justify-center">
          <span className="font-mono text-[9px] text-white/40 mb-3 block text-center uppercase tracking-widest">
            TACTILE SELECTOR: CELLULAR SECTION
          </span>
          
          <div className="relative w-48 h-48 flex items-center justify-center bg-black/40 rounded-full border border-white/5 shadow-[inset_0_0_20px_rgba(46,252,158,0.15)] overflow-visible">
            {/* Cell Membrane edge loop */}
            <div className="absolute inset-2 border-2 border-dashed border-emerald-glow/20 rounded-full animate-pulse-slow" />
            
            {/* Nucleus Core Button */}
            <button
              onClick={() => setSelectedOrganelle(ORGANELLES[0])}
              className={`absolute w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 pointer-events-auto border cursor-pointer ${
                selectedOrganelle.id === "nucleus"
                  ? "bg-cyan-500/35 border-cyan-400 scale-110 shadow-[0_0_15px_rgba(6,182,212,0.4)]"
                  : "bg-white/5 border-white/10 hover:border-cyan-500/50"
              }`}
            >
              <div className="w-3 h-3 bg-cyan-400 rounded-full animate-ping absolute" />
              <span className="font-mono text-[9px] text-cyan-200 uppercase font-bold">CORE</span>
            </button>

            {/* Mitochondria satellite button */}
            <button
              onClick={() => setSelectedOrganelle(ORGANELLES[1])}
              className={`absolute top-4 right-4 w-11 h-11 rounded-3xl flex items-center justify-center transition-all duration-300 pointer-events-auto border cursor-pointer ${
                selectedOrganelle.id === "mitochondria"
                  ? "bg-emerald-500/35 border-emerald-400 scale-110 shadow-[0_0_15px_rgba(16,185,129,0.4)]"
                  : "bg-white/5 border-white/10 hover:border-emerald-500/50"
              }`}
            >
              <Zap className="w-3.5 h-3.5 text-emerald-300" />
            </button>

            {/* Ribosome button */}
            <button
              onClick={() => setSelectedOrganelle(ORGANELLES[2])}
              className={`absolute bottom-5 left-3 w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300 pointer-events-auto border cursor-pointer ${
                selectedOrganelle.id === "ribosome"
                  ? "bg-amber-500/35 border-amber-400 scale-110 shadow-[0_0_15px_rgba(245,158,11,0.4)]"
                  : "bg-white/5 border-white/10 hover:border-amber-500/50"
              }`}
            >
              <span className="font-mono text-[8px] text-amber-200">PRINT</span>
            </button>

            {/* Endoplasmic Reticulum outer spiral layer */}
            <button
              onClick={() => setSelectedOrganelle(ORGANELLES[3])}
              className={`absolute bottom-4 right-5 w-12 h-10 rounded-2xl flex items-center justify-center transition-all duration-300 pointer-events-auto border cursor-pointer ${
                selectedOrganelle.id === "endoplasmic_reticulum"
                  ? "bg-purple-500/35 border-purple-400 scale-110 shadow-[0_0_15px_rgba(139,92,246,0.4)]"
                  : "bg-white/5 border-white/10 hover:border-purple-500/50"
              }`}
            >
              <Cpu className="w-4 h-4 text-purple-300" />
            </button>
          </div>
          
          <div className="flex items-center gap-1.5 mt-4">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-glow inline-block animate-ping" />
            <span className="text-[10px] font-mono text-white/50 uppercase">INTERACTION PROBE ACTIVE</span>
          </div>
        </div>

        {/* Diagnostic readout logs panel */}
        <div className="w-full md:w-1/2 flex flex-col justify-between border-t md:border-t-0 md:border-l border-white/10 pt-4 md:pt-0 md:pl-5">
          <div className="flex flex-col gap-2.5">
            <span className="font-mono text-[9px] text-[#2efc9e]/80 uppercase tracking-widest leading-none">
              DIAGNOSTIC TELEMETRY
            </span>
            <h4 className="text-sm font-semibold text-white tracking-wide">
              {selectedOrganelle.name}
            </h4>
            <p className="text-[10px] font-mono text-white/40 italic">
              {selectedOrganelle.scienceName}
            </p>
            <p className="text-xs text-white/70 leading-relaxed font-sans">
              {selectedOrganelle.functionDesc}
            </p>
          </div>

          <div className="mt-4 flex flex-col gap-2 border-t border-white/5 pt-3">
            <div className="flex items-center justify-between text-[10px] font-mono">
              <span className="text-white/40">ENERGETIC BALANCE:</span>
              <span className="text-emerald-glow font-semibold select-none">{selectedOrganelle.energyOutput}</span>
            </div>
            <div className="flex items-center justify-between text-[10px] font-mono">
              <span className="text-white/40">COMPLEXITY THRESHOLD:</span>
              <span className="text-white font-semibold">{selectedOrganelle.complexityIndex}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Slider modifier for metabolic rate */}
      <div className="glass-panel p-4 rounded-xl border border-white/5 flex items-center justify-between gap-4 font-mono text-xs">
        <div className="flex flex-col">
          <span className="text-white/40 text-[10px]">TOTAL MITOCHONDRIAL RESPIN RANGE</span>
          <span className="text-white font-bold">{cellularMetabolicRate}% CORE THROTTLE</span>
        </div>
        <div className="flex-1 max-w-[200px]">
          <input
            type="range"
            min="30"
            max="120"
            value={cellularMetabolicRate}
            onChange={(e) => setCellularMetabolicRate(parseInt(e.target.value))}
            className="w-full accent-emerald-glow h-1 bg-white/10 rounded-lg cursor-pointer"
          />
        </div>
      </div>
    </div>
  );
}
