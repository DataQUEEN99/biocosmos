import React, { useState } from "react";
import { Chapter } from "../../types";
import { ShieldAlert, Target, RefreshCw, Hand } from "lucide-react";

interface ChapterProps {
  chapter: Chapter;
}

interface ThreatVirus {
  id: number;
  type: string;
  x: number;
  y: number;
  scale: number;
  speed: number;
}

export default function Chapter8Disease({ chapter }: ChapterProps) {
  const [immuneScore, setImmuneScore] = useState(0);
  const [threats, setThreats] = useState<ThreatVirus[]>([
    { id: 1, type: "Influenza Spike", x: 25, y: 30, scale: 1.2, speed: 1 },
    { id: 2, type: "Rhinovirus Core", x: 70, y: 35, scale: 1.0, speed: 1.2 },
    { id: 3, type: "Coronavirus Envelope", x: 45, y: 65, scale: 1.4, speed: 0.8 },
    { id: 4, type: "Adenovirus Vector", x: 80, y: 70, scale: 0.9, speed: 1.5 },
  ]);

  const handlePhagocytosis = (id: number) => {
    // Engulf targeted virus threat
    setThreats((prev) => prev.filter((t) => t.id !== id));
    setImmuneScore((prev) => prev + 1);

    // Respawn a new threat to keep interaction fluid
    setTimeout(() => {
      const respawned: ThreatVirus = {
        id: Date.now(),
        type: ["Influenza Spike", "Rhinovirus Core", "Phage Variant", "Coronavirus Envelope"][Math.floor(Math.random() * 4)],
        x: 20 + Math.random() * 60,
        y: 20 + Math.random() * 60,
        scale: 0.8 + Math.random() * 0.7,
        speed: 0.8 + Math.random() * 0.8,
      };
      setThreats((prev) => [...prev, respawned]);
    }, 1200);
  };

  const handleReset = () => {
    setThreats([
      { id: 1, type: "Influenza Spike", x: 25, y: 30, scale: 1.2, speed: 1 },
      { id: 2, type: "Rhinovirus Core", x: 70, y: 35, scale: 1.0, speed: 1.2 },
      { id: 3, type: "Coronavirus Envelope", x: 45, y: 65, scale: 1.4, speed: 0.8 },
      { id: 4, type: "Adenovirus Vector", x: 80, y: 70, scale: 0.9, speed: 1.5 },
    ]);
    setImmuneScore(0);
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-xl md:max-w-2xl px-2">
      <div className="flex items-center gap-2 font-mono text-[11px] text-[#bd34fe] uppercase tracking-widest leading-none">
        <ShieldAlert className="w-4 h-4 text-[#bd34fe] animate-pulse" />
        <span>Vascular Interception Warfare</span>
      </div>

      <h3 className="text-xl md:text-2xl font-serif text-white leading-tight">
        Mobilize Macrophage Phagocytosis to Absorb Pathogens
      </h3>

      <p className="text-sm text-white/70 leading-relaxed font-sans">
        Viruses hijack cellular machinery via molecular spike keys. Click active viral invaders inside the arterial visualizer below to engulf and destroy them before they attach to host receptors.
      </p>

      {/* Immune simulation frame */}
      <div className="glass-panel p-5 rounded-2xl border border-purple-glow/20 flex flex-col gap-4 relative overflow-hidden bg-gradient-to-br from-black/60 to-purple-glow/5">
        <div className="flex items-center justify-between border-b border-white/5 pb-3">
          <div className="flex items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-400 animate-ping" />
            <span className="font-mono text-xs text-white/50">VASCULAR SHIELD SCORE:</span>
            <span className="font-mono font-bold text-emerald-glow">{immuneScore * 14} Pts</span>
          </div>
          <button
            onClick={handleReset}
            className="flex items-center gap-1 text-[10px] font-mono text-white/30 hover:text-white transition-colors cursor-pointer"
          >
            <RefreshCw className="w-3 h-3" />
            RESET SHIELDS
          </button>
        </div>

        {/* Dynamic vascular field backdrop */}
        <div className="relative h-48 bg-black/60 border border-white/5 rounded-xl overflow-hidden flex items-center justify-center">
          {threats.length === 0 ? (
            <div className="text-center p-4">
              <span className="text-xs font-mono text-emerald-glow font-bold uppercase animate-pulse">
                ARTERIAL CANAL STABILIZED - ALL PATHOGENS ENGULFED
              </span>
            </div>
          ) : (
            <>
              {/* Background blood cells flowing */}
              <div className="absolute inset-0 pointer-events-none opacity-20">
                <div className="absolute w-6 h-6 bg-red-500 rounded-full blur-[1px] animate-pulse" style={{ left: "20%", top: "40%" }} />
                <div className="absolute w-8 h-8 bg-red-500 rounded-full blur-[1px] animate-pulse" style={{ left: "65%", top: "25%", animationDelay: "0.5s" }} />
                <div className="absolute w-5 h-5 bg-red-500 rounded-full blur-[1px] animate-pulse" style={{ left: "50%", top: "75%", animationDelay: "1s" }} />
              </div>

              {threats.map((threat) => (
                <button
                  key={threat.id}
                  onClick={() => handlePhagocytosis(threat.id)}
                  className="absolute p-4 rounded-full border border-red-500/30 bg-red-500/10 hover:bg-emerald-glow/20 hover:border-emerald-glow transition-all duration-300 transform -translate-x-1/2 -translate-y-1/2 flex items-center justify-center cursor-pointer group active:scale-90"
                  style={{
                    left: `${threat.x}%`,
                    top: `${threat.y}%`,
                    transform: `translate(-50%, -50%) scale(${threat.scale})`,
                  }}
                  title={`Engulf ${threat.type}`}
                >
                  {/* Glowing core */}
                  <Target className="w-5 h-5 text-red-400 group-hover:text-emerald-glow animate-spin" style={{ animationDuration: "10s" }} />
                  <span className="absolute bottom-[-15px] text-[8px] font-mono text-white/50 tracking-tighter hidden md:inline truncate w-24 text-center">
                    {threat.type}
                  </span>
                </button>
              ))}
            </>
          )}

          {/* Prompt guide helper */}
          <div className="absolute top-2 right-3 flex items-center gap-1.5 text-white/30 text-[9px] font-mono pointer-events-none uppercase">
            <Hand className="w-3.5 h-3.5" />
            <span>CLICK THREATS TO ENGULF</span>
          </div>
        </div>

        {/* Scientific readout footnote */}
        <div className="p-3 bg-white/5 border border-white/5 rounded-xl flex flex-col gap-1 font-mono text-[10px]">
          <div className="flex items-center justify-between text-[#bd34fe]">
            <span>ANTIBODY TITERS:</span>
            <span className="font-bold">IGG RESPONSIVE MATCH</span>
          </div>
          <p className="text-[9px] text-white/40 leading-tight">
            Immune cells utilize molecular antigen tagging to detect non-self structures, targeting liposomes and viral spikes for rapid macrophage assimilation.
          </p>
        </div>
      </div>
    </div>
  );
}
