import React, { useState } from "react";
import { Chapter } from "../../types";
import { Zap, Cpu, RefreshCw, CpuIcon } from "lucide-react";

interface ChapterProps {
  chapter: Chapter;
}

export default function Chapter9AI({ chapter }: ChapterProps) {
  const [synapticEfficiency, setSynapticEfficiency] = useState(74);
  const [pulseCount, setPulseCount] = useState(3);
  const [selectedNode, setSelectedNode] = useState<number | null>(null);

  const bioNeurons = [
    { id: 1, name: "Somatosensory neocortex", freq: "35 Hz" },
    { id: 2, name: "Hippocampal CA3 trace", freq: "58 Hz" },
    { id: 3, name: "Prefrontal axon terminal", freq: "84 Hz" },
  ];

  const triggerPulse = (nodeId: number) => {
    setSelectedNode(nodeId);
    setPulseCount((prev) => prev + 1);
    
    // Increment network speed
    if (synapticEfficiency < 98) {
      setSynapticEfficiency((prev) => Math.min(100, prev + 2));
    }

    setTimeout(() => {
      setSelectedNode(null);
    }, 600);
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-xl md:max-w-2xl px-2">
      <div className="flex items-center gap-2 font-mono text-[11px] text-cyan-glow uppercase tracking-widest leading-none">
        <Cpu className="w-5 h-5 text-cyan-glow" />
        <span>Somatic Digital Interface</span>
      </div>

      <h3 className="text-xl md:text-2xl font-serif text-white leading-tight">
        Propagate Cerebrum Action Potentials into Silicon Arrays
      </h3>

      <p className="text-sm text-white/70 leading-relaxed font-sans">
        The synaptic divide bridges organic and synthetic networks. Click active cerebral cortex zones below to trigger spike ionic rushes and synchronize digital feedforward weights.
      </p>

      {/* Network Interface panel */}
      <div className="glass-panel p-5 rounded-2xl border border-cyan-glow/20 flex flex-col gap-4 bg-gradient-to-br from-black/60 to-cyan-glow/5">
        <div className="flex items-center justify-between border-b border-white/5 pb-3 font-mono">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-glow animate-ping" />
            <span className="text-xs text-white/50">COGNITIVE SYNC EFFICIENCY:</span>
            <span className="font-bold text-cyan-glow">{synapticEfficiency}% NOMINAL</span>
          </div>
          <button
            onClick={() => {
              setSynapticEfficiency(74);
              setPulseCount(3);
            }}
            className="text-[10px] text-white/30 hover:text-white transition-colors cursor-pointer"
          >
            RESET ALIGNMENT
          </button>
        </div>

        {/* 2D Interactive neural mapping layout */}
        <div className="relative h-44 bg-black/60 border border-white/5 rounded-xl overflow-hidden flex items-center justify-between px-6 md:px-12">
          {/* Left: Bio-nodes */}
          <div className="flex flex-col gap-3 z-10">
            <span className="text-[8px] font-mono text-[#bd34fe] uppercase tracking-widest leading-none mb-1">
              Somatic Nodes
            </span>
            {bioNeurons.map((node) => {
              const isSelected = selectedNode === node.id;
              return (
                <button
                  key={node.id}
                  onClick={() => triggerPulse(node.id)}
                  className={`px-3 py-1.5 rounded-lg border text-left transition-all duration-300 transform pointer-events-auto cursor-pointer ${
                    isSelected
                      ? "bg-[#bd34fe]/25 border-[#bd34fe] text-white scale-105 shadow-[0_0_12px_rgba(189,52,254,0.3)]"
                      : "bg-white/5 border-white/5 hover:border-[#bd34fe]/40 text-white/70"
                  }`}
                >
                  <p className="text-[10px] font-bold uppercase tracking-wider">{node.name.split(" ")[0]}</p>
                  <span className="text-[8px] font-mono opacity-50 block">{node.freq}</span>
                </button>
              );
            })}
          </div>

          {/* Center Connector laser beam pulses */}
          <div className="flex-1 px-4 relative h-1 bg-white/5 flex items-center justify-center overflow-visible">
            {selectedNode && (
              <span className="absolute h-[3px] bg-gradient-to-r from-[#bd34fe] to-cyan-glow shadow-[0_0_8px_rgba(0,240,255,0.7)] rounded-full w-full left-0 animate-pulse" />
            )}
            <span className="font-mono text-[8px] text-white/30 bg-black/90 px-1.5 absolute top-[8px]">
              {pulseCount} SPIKES PROPAGATING
            </span>
          </div>

          {/* Right: Silicon units */}
          <div className="flex flex-col gap-3 z-10 text-right">
            <span className="text-[8px] font-mono text-cyan-glow uppercase tracking-widest leading-none mb-1">
              Silicon Layer
            </span>
            <div className="p-3 bg-cyan-glow/5 border border-cyan-glow/20 rounded-xl max-w-[130px] flex flex-col justify-end">
              <CpuIcon className="w-5 h-5 text-cyan-glow mb-1 self-end animate-spin" style={{ animationDuration: "12s" }} />
              <p className="text-[10px] text-white font-bold uppercase tracking-wider">WEIGHT_3x1</p>
              <span className="text-[8px] font-mono text-[#2efc9e]">+(0.{pulseCount * 7}) bias</span>
            </div>
          </div>
        </div>

        {/* Conceptual brief footer info */}
        <div className="p-3.5 bg-white/5 border border-white/5 rounded-xl flex items-center gap-2.5">
          <Zap className="w-4 h-4 text-cyan-glow animate-pulse" />
          <p className="text-[10px] font-mono text-white/50 leading-relaxed uppercase">
            IONIC TRANSMISSION REGISTERED. EVERY CLIK SHIFTS ARTIFICIAL WEGHTS DIRECTLY TO STRENGTH COGNITION.
          </p>
        </div>
      </div>
    </div>
  );
}
