import React, { useState } from "react";
import { Chapter } from "../../types";
import { Sparkles, Terminal, Rocket, Check, RefreshCw, Cpu } from "lucide-react";

interface ChapterProps {
  chapter: Chapter;
}

interface CodonSegment {
  code: string;
  name: string;
  utility: string;
  color: string;
}

const BIO_CODONS: CodonSegment[] = [
  { code: "RDR", name: "Deinococcus Radiation Shield", utility: "Restructures double-strand DNA fractures in real time under heavy cosmic gamma rays.", color: "text-amber-300 border-amber-500/30" },
  { code: "CHL", name: "Vacuum Chlorophyll Synthesizer", utility: "Enables autonomous dermal glucose synthesis from solar radiation without atmospheric pressure.", color: "text-[#2efc9e] border-emerald-500/30" },
  { code: "GFT", name: "Hyper G-Force Elasticity", utility: "Synthesizes advanced vascular collagen loops protecting cerebral flow during extreme acceleration.", color: "text-cyan-glow border-cyan-500/30" },
  { code: "XEN", name: "Xenobiotic Nucleobase (X-Y Pair)", utility: "Expands the standard 4-base codon system with non-natural synthetic pairs, yielding custom amino peptides.", color: "text-[#bd34fe] border-purple-500/30" }
];

export default function Chapter10Future({ chapter }: ChapterProps) {
  const [selectedCodons, setSelectedCodons] = useState<string[]>([]);
  const [isCompiled, setIsCompiled] = useState(false);

  const toggleCodon = (code: string) => {
    if (isCompiled) return;
    setSelectedCodons((current) =>
      current.includes(code)
        ? current.filter((c) => c !== code)
        : [...current, code]
    );
  };

  const handleCompile = () => {
    if (selectedCodons.length === 0) return;
    setIsCompiled(true);
  };

  const handleReset = () => {
    setSelectedCodons([]);
    setIsCompiled(false);
  };

  return (
    <div className="flex flex-col gap-6 w-full max-w-xl md:max-w-2xl px-2">
      <div className="flex items-center gap-2 font-mono text-[11px] text-emerald-glow uppercase tracking-widest leading-none">
        <Cpu className="w-5 h-5 text-emerald-glow" />
        <span>Quantum Bio-Synthesis Bay</span>
      </div>

      <h3 className="text-xl md:text-2xl font-serif text-white leading-tight">
        Sequence Extremophile Codons for Cosmic Voyages
      </h3>

      <p className="text-sm text-white/70 leading-relaxed font-sans">
        Design trans-stellar organisms capable of withstanding foreign worlds. Queue biological structural traits below, and execute synthetic genomic compilation.
      </p>

      {/* Synthesis console */}
      <div className="glass-panel p-5 rounded-2xl border border-emerald-glow/20 flex flex-col gap-4 relative overflow-hidden bg-gradient-to-br from-black/60 to-emerald-glow/5">
        
        {/* Terminal Header */}
        <div className="flex items-center justify-between border-b border-white/5 pb-3 font-mono">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-glow animate-ping" />
            <span className="text-xs text-white/50">GENOMIC SEQUENCE BUFFER:</span>
            <span className="font-bold text-white uppercase">{selectedCodons.length} SELECTED</span>
          </div>
          <button
            onClick={handleReset}
            className="text-[10px] text-white/30 hover:text-white transition-colors flex items-center gap-1 cursor-pointer"
          >
            <RefreshCw className="w-3 h-3" />
            CLEAR QUEUE
          </button>
        </div>

        {/* Selected custom genome stream lineup */}
        <div className="bg-black/50 p-4 border border-white/5 rounded-xl flex items-center justify-center min-h-[90px] relative">
          {selectedCodons.length === 0 ? (
            <div className="text-center">
              <Terminal className="w-5 h-5 text-white/20 mx-auto mb-1 animate-pulse" />
              <p className="text-[10px] font-mono text-white/30 uppercase">
                BUFFER EMPTY. ACTIVATE EXTREMOPHILE CODON SCHEMAS BELOW...
              </p>
            </div>
          ) : (
            <div className="flex flex-wrap gap-2 justify-center items-center">
              {selectedCodons.map((code) => {
                const codon = BIO_CODONS.find(c => c.code === code);
                return (
                  <div
                    key={code}
                    className={`px-3 py-1.5 rounded-lg border bg-emerald-glow/5 flex items-center gap-2 border-emerald-glow/30 ${codon?.color}`}
                  >
                    <span className="font-mono font-black text-xs">{code}</span>
                    <span className="text-[9px] font-sans opacity-80 leading-none">{codon?.name.split(" ")[0]}</span>
                    {isCompiled && <Check className="w-3.5 h-3.5 text-[#2efc9e]" />}
                  </div>
                );
              })}

              {!isCompiled && (
                <button
                  id="compile-synth-cell"
                  onClick={handleCompile}
                  className="px-4 py-1.5 rounded-lg bg-emerald-glow text-black font-mono font-bold text-xs hover:scale-105 active:scale-95 transition-all pointer-events-auto cursor-pointer"
                >
                  COMPILE SEQUENCE
                </button>
              )}
            </div>
          )}
        </div>

        {/* Codons Selector list */}
        <div className="space-y-2 mt-1">
          {BIO_CODONS.map((codon) => {
            const isSelected = selectedCodons.includes(codon.code);
            return (
              <button
                key={codon.code}
                disabled={isCompiled}
                onClick={() => toggleCodon(codon.code)}
                className={`w-full p-3 rounded-xl border text-left flex items-start gap-3.5 transition-all duration-300 pointer-events-auto ${
                  isCompiled ? "opacity-60 cursor-not-allowed" : "cursor-pointer"
                } ${
                  isSelected
                    ? "bg-emerald-500/10 border-emerald-glow"
                    : "bg-white/5 border-white/5 hover:bg-white/10"
                }`}
              >
                <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-mono font-black border text-xs ${
                  isSelected ? "bg-emerald-glow text-black" : "bg-black/35 text-white/40"
                }`}>
                  {codon.code}
                </div>
                <div className="flex-1">
                  <h4 className="text-xs font-bold text-white uppercase tracking-wider">{codon.name}</h4>
                  <p className="text-[10px] text-white/50 leading-normal mt-1">{codon.utility}</p>
                </div>
              </button>
            );
          })}
        </div>

        {/* Success Hologram readouts when compiled */}
        {isCompiled && (
          <div className="mt-3 p-4 bg-emerald-500/10 border border-emerald-glow/30 rounded-2xl flex items-center gap-3.5 animate-pulse">
            <Rocket className="w-6 h-6 text-emerald-glow" />
            <div>
              <p className="text-xs font-bold text-white uppercase font-sans tracking-wide">
                Designer Strain Generated Perfectly
              </p>
              <p className="text-[10px] text-white/60 leading-normal">
                Genome assembled successfully. Base replication rate structured at 0-G gravity limits. Life forms ready for launch to hydrothermal Jovian ocean probes.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
