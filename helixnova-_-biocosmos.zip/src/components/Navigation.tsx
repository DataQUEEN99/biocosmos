import React, { useState, useEffect, useRef } from "react";
import { Chapter, ChapterId } from "../types";
import { Volume2, VolumeX, Compass, CircleDot, ChevronUp, ChevronDown, Sparkles } from "lucide-react";

interface NavigationProps {
  chapters: Chapter[];
  currentChapter: Chapter;
  onSelectChapter: (id: ChapterId) => void;
}

export default function Navigation({ chapters, currentChapter, onSelectChapter }: NavigationProps) {
  const [soundActive, setSoundActive] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const droneOscRef = useRef<OscillatorNode | null>(null);
  const droneGainRef = useRef<GainNode | null>(null);

  // Initialize background drone when sound is activated
  const startSynthEngine = () => {
    try {
      if (soundActive) {
        // Turn off sound
        if (droneOscRef.current) {
          try { droneOscRef.current.stop(); } catch (e) {}
          droneOscRef.current.disconnect();
          droneOscRef.current = null;
        }
        if (audioCtxRef.current) {
          audioCtxRef.current.close().then(() => {
            audioCtxRef.current = null;
          });
        }
        setSoundActive(false);
        return;
      }

      // Initialize browser AudioContext on user interaction
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;

      const ctx = new AudioContextClass();
      audioCtxRef.current = ctx;

      // 1. Create continuous ambient bio-rumble drone
      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(0.08, ctx.currentTime);
      masterGain.connect(ctx.destination);

      const osc = ctx.createOscillator();
      const rawOsc = ctx.createOscillator();
      const filter = ctx.createBiquadFilter();

      // Slow wave modulation
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(55, ctx.currentTime); // A1 note (sub bass)

      rawOsc.type = "sine";
      rawOsc.frequency.setValueAtTime(110, ctx.currentTime); // A2 note

      filter.type = "lowpass";
      filter.frequency.setValueAtTime(200, ctx.currentTime);

      osc.connect(filter);
      rawOsc.connect(filter);

      const droneGain = ctx.createGain();
      droneGain.gain.setValueAtTime(0.4, ctx.currentTime);
      filter.connect(droneGain);
      droneGain.connect(masterGain);

      osc.start();
      rawOsc.start();

      droneOscRef.current = osc;
      droneGainRef.current = droneGain;

      setSoundActive(true);

      // Play introductory cinematic chime
      triggerChime(ctx, 440, "sine"); // A4
      setTimeout(() => triggerChime(ctx, 659.25, "triangle"), 150); // E5
    } catch (error) {
      console.warn("Failed to boot sound engine: ", error);
    }
  };

  // Play micro chime interaction sound
  const triggerChime = (ctx: AudioContext, freq: number, type: OscillatorType = "sine") => {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, ctx.currentTime);

    // Easing chime sound decline
    gain.gain.setValueAtTime(0.12, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.2);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start();
    osc.stop(ctx.currentTime + 1.2);
  };

  // Trigger high resonance chimes on chapter change
  useEffect(() => {
    if (soundActive && audioCtxRef.current) {
      const baseFreqs: Record<string, number> = {
        gold: 329.63, // E4
        emerald: 392.00, // G4
        cyan: 440.00, // A4
        violet: 523.25, // C5
      };
      const freq = baseFreqs[currentChapter.accentColor] || 440;
      triggerChime(audioCtxRef.current, freq, "sine");
      // Add a higher harmonics ripple
      setTimeout(() => {
        if (audioCtxRef.current) {
          triggerChime(audioCtxRef.current, freq * 1.5, "triangle");
        }
      }, 100);

      // Mutate low drone frequency key based on active chapters
      if (droneOscRef.current && audioCtxRef.current) {
        const droneFreq = 40 + currentChapter.id * 5;
        droneOscRef.current.frequency.exponentialRampToValueAtTime(droneFreq, audioCtxRef.current.currentTime + 1.5);
      }
    }
  }, [currentChapter, soundActive]);

  // Handle keys for accessibility (ArrowUp/ArrowDown to switch chapters)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "ArrowUp" || e.key === "ArrowLeft") {
        e.preventDefault();
        const prevId = currentChapter.id > 1 ? (currentChapter.id - 1) as ChapterId : 10;
        onSelectChapter(prevId);
      } else if (e.key === "ArrowDown" || e.key === "ArrowRight") {
        e.preventDefault();
        const nextId = currentChapter.id < 10 ? (currentChapter.id + 1) as ChapterId : 1;
        onSelectChapter(nextId);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [currentChapter.id, onSelectChapter]);

  const percentage = Math.round((currentChapter.id / 10) * 100);

  return (
    <>
      {/* 1. Header Navigation Bar */}
      <header
        id="helixnova-header"
        className="fixed top-0 left-0 right-0 z-50 h-20 flex items-center justify-between px-6 md:px-12 glass-panel border-b border-white/5 select-none"
      >
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => onSelectChapter(1)}>
          <div className="relative w-10 h-10 flex items-center justify-center rounded-full bg-cyan-glow/10 border border-cyan-glow/40 animate-pulse-slow">
            <Compass className="w-5 h-5 text-cyan-glow" />
            <div className="absolute inset-0 bg-cyan-glow/20 rounded-full blur-sm" />
          </div>
          <div>
            <span className="font-sans font-bold tracking-widest text-[#f3f4f6] text-sm">HELIXNOVA</span>
            <span className="mx-1.5 text-white/30">/</span>
            <span className="text-xs font-mono tracking-widest text-white/50">BIOCOSMOS</span>
          </div>
        </div>

        {/* Dynamic Navigation HUD Status */}
        <div className="hidden lg:flex items-center gap-8 font-mono text-xs text-white/60">
          <div className="flex items-center gap-2">
            <span className="text-white/30">NARRATIVE COORD:</span>
            <span className="text-gradient-cyan font-bold">{currentChapter.scientificTerm}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-white/30">EPOCH:</span>
            <span className="text-white font-semibold">{currentChapter.narrativeTime}</span>
          </div>
        </div>

        {/* Cinematic Settings Controller */}
        <div className="flex items-center gap-4">
          <button
            id="synth-sound-ctrl"
            onClick={startSynthEngine}
            className={`p-2.5 rounded-full border transition-all duration-300 flex items-center gap-2 group hover:scale-105 active:scale-95 cursor-pointer ${
              soundActive
                ? "bg-cyan-glow/15 border-cyan-glow/50 text-cyan-glow shadow-[0_0_15px_rgba(0,240,255,0.25)]"
                : "bg-white/5 border-white/10 text-white/60 hover:text-white hover:border-white/20"
            }`}
            title="Toggle Generative Spatial Soundscape"
          >
            {soundActive ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            <span className="text-[10px] font-mono tracking-wider pr-1 hidden sm:inline">
              {soundActive ? "SYNTH LEVEL: ACTIVE" : "SYNTH OFF"}
            </span>
            {soundActive && (
              <div className="flex items-center gap-0.5 h-3">
                <span className="w-0.5 h-full bg-cyan-glow origin-bottom bar-anim" style={{ animationDelay: "0.1s" }} />
                <span className="w-0.5 h-4/5 bg-cyan-glow origin-bottom bar-anim" style={{ animationDelay: "0.3s" }} />
                <span className="w-0.5 h-2/3 bg-cyan-glow origin-bottom bar-anim" style={{ animationDelay: "0.5s" }} />
              </div>
            )}
          </button>
        </div>
      </header>

      {/* 2. Floating Sidebar Radial Coordinates Selector */}
      <nav
        id="helixnova-sidebar-coord"
        className="fixed right-6 md:right-8 top-1/2 -translate-y-1/2 z-40 hidden md:flex flex-col gap-3 glass-panel-heavy p-4 rounded-full border border-white/5"
      >
        <button
          onClick={() => {
            const prevId = currentChapter.id > 1 ? (currentChapter.id - 1) as ChapterId : 10;
            onSelectChapter(prevId);
          }}
          className="p-1 px-1.5 text-white/40 hover:text-cyan-glow transition-colors font-semibold flex flex-col items-center hover:scale-115 active:scale-90"
        >
          <ChevronUp className="w-5 h-5" />
          <span className="text-[8px] font-mono tracking-tighter">PREV</span>
        </button>

        <div className="w-[1px] h-3 bg-white/10 self-center" />

        {chapters.map((ch) => {
          const isActive = ch.id === currentChapter.id;
          return (
            <button
              key={ch.id}
              onClick={() => onSelectChapter(ch.id)}
              className="relative group flex items-center justify-center p-2.5 outline-none cursor-pointer"
              title={`View Chapter ${ch.id}: ${ch.shortTitle}`}
            >
              {/* Inner Circle Dot */}
              <CircleDot
                className={`w-3.5 h-3.5 transition-all duration-300 ${
                  isActive
                    ? "text-cyan-glow scale-125 stroke-[3]"
                    : "text-white/20 group-hover:text-white/60 group-hover:scale-110"
                }`}
              />

              {/* Glowing Radial Halo */}
              {isActive && (
                <span className="absolute inset-2 bg-cyan-glow/20 rounded-full blur-[4px] animate-ping" />
              )}

              {/* Futuristic floating card on hover */}
              <div className="absolute right-10 top-1/2 -translate-y-1/2 translate-x-3 pointer-events-none opacity-0 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300 glass-panel-heavy px-3.5 py-2 rounded-lg border border-cyan-glow/25 text-right w-44">
                <p className="text-[9px] font-mono tracking-widest text-[#a855f7]">CHAPTER 0{ch.id}</p>
                <p className="text-xs font-bold font-sans text-white uppercase tracking-wider">{ch.shortTitle}</p>
                <p className="text-[10px] font-mono text-white/50 truncate">{ch.scientificTerm}</p>
              </div>
            </button>
          );
        })}

        <div className="w-[1px] h-3 bg-white/10 self-center" />

        <button
          onClick={() => {
            const nextId = currentChapter.id < 10 ? (currentChapter.id + 1) as ChapterId : 1;
            onSelectChapter(nextId);
          }}
          className="p-1 px-1.5 text-white/40 hover:text-cyan-glow transition-colors font-semibold flex flex-col items-center hover:scale-115 active:scale-90"
        >
          <span className="text-[8px] font-mono tracking-tighter">NEXT</span>
          <ChevronDown className="w-5 h-5" />
        </button>
      </nav>

      {/* 3. Bottom Progress HUD */}
      <footer
        id="helixnova-timeline-hud"
        className="fixed bottom-0 left-0 right-0 z-40 h-10 px-6 md:px-12 flex items-center justify-between glass-panel border-t border-white/5 font-mono text-[10px] text-white/40"
      >
        <div className="flex items-center gap-4">
          <span>COSMOS STAGE:</span>
          <span className="text-white/80 font-bold">&lt; CHAPTER 0{currentChapter.id} of 10 &gt;</span>
        </div>

        {/* Interactive progress bar */}
        <div className="flex-1 max-w-md mx-8 relative h-1 bg-white/10 rounded-full overflow-hidden hidden md:block">
          <div
            id="active-chapter-percentage"
            className="absolute left-0 top-0 h-full bg-gradient-to-r from-violet-glow to-cyan-glow rounded-full shadow-[0_0_8px_rgba(0,240,255,0.6)] transition-all duration-500 ease-out"
            style={{ width: `${percentage}%` }}
          />
        </div>

        <div className="flex items-center gap-1.5 text-cyan-glow/80 glow-cyan">
          <Sparkles className="w-3.5 h-3.5" />
          <span className="font-bold">{percentage}% REVELATION ACHIEVED</span>
        </div>
      </footer>
    </>
  );
}
