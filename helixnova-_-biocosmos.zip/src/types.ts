export type ChapterId = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10;

export interface Chapter {
  id: ChapterId;
  shortTitle: string;
  title: string;
  scientificTerm: string;
  subtitle: string;
  summary: string;
  storySegment: string;
  accentColor: string; // e.g. "cyan" | "violet" | "emerald" | "gold"
  glowColor: string; // Tailwind hex color or var
  narrativeTime: string; // e.g., "3.8 Billion Years Ago"
}

export const CHAPTERS: Chapter[] = [
  {
    id: 1,
    shortTitle: "Origin",
    scientificTerm: "Primordial Abiogenesis",
    title: "The Birth of Life",
    subtitle: "Hydrothermal Vents & Primitive Chemistry",
    summary: "Deep in the dark Archean ocean, where superheated mineral columns bleed elements into chilled ocean floor water, primitive carbon bonds and metallic grids spark the first self-sustaining metabolic feedback loop.",
    storySegment: "Under intense pressure, simple carbon molecules adhere to porous iron-sulfur chambers, giving rise to self-replicating chemical machinery. This is where RNA begins to dream.",
    accentColor: "gold",
    glowColor: "#f9d949",
    narrativeTime: "3.8 Billion Years Ago"
  },
  {
    id: 2,
    shortTitle: "The Cell",
    scientificTerm: "Eukaryogenesis",
    title: "Internal Microcosmos",
    subtitle: "The Complexity Threshold",
    summary: "A colossal evolutionary merger is born. Free-living bacterial ancestors integrate inside a host host cell, giving rise to mitochondria—the energy-forging reactors of the living world.",
    storySegment: "Travel through organelles encased inside dynamic double-lipid barriers. Observe cellular transport vectors, energetic fuel factories, and synthetic machines processing structural destiny.",
    accentColor: "emerald",
    glowColor: "#2efc9e",
    narrativeTime: "1.8 Billion Years Ago"
  },
  {
    id: 3,
    shortTitle: "DNA",
    scientificTerm: "Helical Polymerization",
    title: "Quantum Blueprints",
    subtitle: "The Geometry of Inheritance",
    summary: "The double helix stands as biology's ultimate encryption program. Four structural nitrogenous molecules hold the precise instructions for translating stellar stardust into living consciousness.",
    storySegment: "Every strand of DNA contains the structural history of every organism which preceded it. Tap nucleobases to trigger transcription enzyme simulation.",
    accentColor: "cyan",
    glowColor: "#00f0ff",
    narrativeTime: "Permanent"
  },
  {
    id: 4,
    shortTitle: "Genes",
    scientificTerm: "Chromatin Topology",
    title: "Aesthetic Constellations",
    subtitle: "The Chromosomal Symmetries",
    summary: "Genes are distinct active coordinates lighting up within dense molecular chromatins. Like space constellations, they encode operational rules for molecular assemblies.",
    storySegment: "Interact with chromosomal folding models. Slide through the active gene networks that define morphological beauty, resilience, and sensory depth.",
    accentColor: "violet",
    glowColor: "#bd34fe",
    narrativeTime: "Ongoing"
  },
  {
    id: 5,
    shortTitle: "Proteins",
    scientificTerm: "Polypeptide Geodesics",
    title: "The Sculpted Engines",
    subtitle: "Folded Structural Machines",
    summary: "Linear generic codes fold in milliseconds into intricate, highly delicate 3D micro-engines operating on fundamental kinetic forces. Form is function in the molecular ballet.",
    storySegment: "No machine designed by humans matches the precision efficiency of an active protein. Experiment with polypeptide tension parameters and watch amino chains reach stable ground state.",
    accentColor: "gold",
    glowColor: "#f9d949",
    narrativeTime: "Microsecond Transitions"
  },
  {
    id: 6,
    shortTitle: "Evolution",
    scientificTerm: "Adaptive Radiation",
    title: "Branching Speciation",
    subtitle: "The Infinite Tree of Forms",
    summary: "From singular origins, life branches into a dazzling botanical and physiological tree. Adaptation carves survival vectors across climatic cycles and planetary drift.",
    storySegment: "Trace taxonomic lifelines from prehistoric aquatic ancestors to advanced cognitive entities. Observe branching events triggered by planetary climate feedback anomalies.",
    accentColor: "emerald",
    glowColor: "#2efc9e",
    narrativeTime: "500 Million Year Arc"
  },
  {
    id: 7,
    shortTitle: "Humanity",
    scientificTerm: "Somatic Self-Awareness",
    title: "Physiological Oceans",
    subtitle: "Organ Systems in Resonance",
    summary: "Millions of cells coordinate in a symphonic symphony. Red blood capillary flow, pulmonary ventilation, and neural fires of synaptic arrays allow stardust to contemplate its origins.",
    storySegment: "Sensing environments in real-time. Feel the organic pulse of high-tension feedback nodes. The heart rhythms, visual cortex pulses, and autonomic lung contractions.",
    accentColor: "cyan",
    glowColor: "#00f0ff",
    narrativeTime: "Present Epoch"
  },
  {
    id: 8,
    shortTitle: "Disease",
    scientificTerm: "Pathogen Interception",
    title: "Immune Armed Struggle",
    subtitle: "The Cellular Warzone",
    summary: "Intrusive molecular hackers—viruses and bacteria—co-opt genetic machinery. In response, defensive macrophage armadas wage total tactical warfare inside your vascular channels.",
    storySegment: "Command cellular defenses. Engage in high-stakes structural phagocytosis to capture and digest foreign viral capsules before genetic infection takes over.",
    accentColor: "violet",
    glowColor: "#bd34fe",
    narrativeTime: "Nanosecond Wars"
  },
  {
    id: 9,
    shortTitle: "Intelligence",
    scientificTerm: "Synaptic Convergence",
    title: "The Double Network",
    subtitle: "Organic Synapses & Digital Nodes",
    summary: "Biological chemical networks reach deep computational thresholds. Here, the soft, saline cerebral cortex constructs silicon structures, initiating the second great cognitive alignment.",
    storySegment: "The synaptic bridge is open. Fire electrical impulses that propagate across biological neuron dendrites, directly transitioning into artificial node layers.",
    accentColor: "cyan",
    glowColor: "#00f0ff",
    narrativeTime: "The Digital Inception"
  },
  {
    id: 10,
    shortTitle: "Future",
    scientificTerm: "Synthetic Biosynthesis",
    title: "Designing BioCosmos",
    subtitle: "The Quantum Biology Frontier",
    summary: "Discarding evolutionary chance, humanity takes up the biological canvas. Constructing synthetic genetic sequences to colonize deep space, harness cosmic rays, and cure mortality.",
    storySegment: "Design synthetic bio-programs. Sequence custom functional codons to design extreme-resilience organisms engineered for space exploration.",
    accentColor: "emerald",
    glowColor: "#2efc9e",
    narrativeTime: "The Horizon Era"
  }
];
