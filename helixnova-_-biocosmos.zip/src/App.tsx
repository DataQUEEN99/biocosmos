import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChapterId, CHAPTERS } from "./types";
import { BookOpen, Sparkles, Navigation as NavIcon, ArrowRight, ArrowLeft, Compass, Info } from "lucide-react";
import AtmosphereCanvas from "./components/AtmosphereCanvas";
import Navigation from "./components/Navigation";

// Import all chapter modules
import Chapter1Origin from "./components/chapters/Chapter1Origin";
import Chapter2Cell from "./components/chapters/Chapter2Cell";
import Chapter3DNA from "./components/chapters/Chapter3DNA";
import Chapter4Genes from "./components/chapters/Chapter4Genes";
import Chapter5Proteins from "./components/chapters/Chapter5Proteins";
import Chapter6Evolution from "./components/chapters/Chapter6Evolution";
import Chapter7Human from "./components/chapters/Chapter7Human";
import Chapter8Disease from "./components/chapters/Chapter8Disease";
import Chapter9AI from "./components/chapters/Chapter9AI";
import Chapter10Future from "./components/chapters/Chapter10Future";

export default function App() {
  const [activeChapterId, setActiveChapterId] = useState<ChapterId>(1);
  const [introActive, setIntroActive] = useState(true);

  const currentChapter = CHAPTERS.find((c) => c.id === activeChapterId) || CHAPTERS[0];

  const handleSelectChapter = (id: ChapterId) => {
    setActiveChapterId(id);
  };

  // Keyboard pagination navigation helpers
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (introActive) return;
      if (e.key === "Backspace") {
        setIntroActive(true);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [introActive]);

  // Direct chapter components mapping selector
  const renderChapterSandbox = () => {
    switch (activeChapterId) {
      case 1:
        return <Chapter1Origin chapter={currentChapter} />;
      case 2:
        return <Chapter2Cell chapter={currentChapter} />;
      case 3:
        return <Chapter3DNA chapter={currentChapter} />;
      case 4:
        return <Chapter4Genes chapter={currentChapter} />;
      case 5:
        return <Chapter5Proteins chapter={currentChapter} />;
      case 6:
        return <Chapter6Evolution chapter={currentChapter} />;
      case 7:
        return <Chapter7Human chapter={currentChapter} />;
      case 8:
        return <Chapter8Disease chapter={currentChapter} />;
      case 9:
        return <Chapter9AI chapter={currentChapter} />;
      case 10:
        return <Chapter10Future chapter={currentChapter} />;
      default:
        return null;
    }
  };

  return (
    <div className="relative min-h-screen w-full bg-cosmic-bg text-gray-200 overflow-x-hidden selection:bg-cyan-glow/30 selection:text-white">
      {/* 1. Immersive Living Astronomical Atmosphere Background */}
      <AtmosphereCanvas currentChapter={currentChapter} />

      <AnimatePresence mode="wait">
        {introActive ? (
          /* --- INTRODUCTORY PORTAL SHIELD --- */
          <motion.div
            key="intro-screen"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, y: -40 }}
            transition={{ duration: 1.2, ease: [0.25, 1, 0.5, 1] }}
            className="relative z-50 min-h-screen flex flex-col items-center justify-between p-6 md:p-12 text-center"
          >
            {/* Top Minimal Credits */}
            <header className="w-full flex justify-between items-center max-w-7xl font-mono text-[9px] tracking-widest text-white/30 uppercase">
              <span>AWWWARDS EXHIBIT EDITION</span>
              <span>EST. 2026 / BIO COSMOLOGY</span>
            </header>

            {/* Central Calligraphy Grid */}
            <main className="flex-1 flex flex-col items-center justify-center max-w-3xl gap-6 relative">
              <motion.div
                initial={{ scale: 0.85, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.3, duration: 1 }}
                className="relative w-16 h-16 flex items-center justify-center rounded-full bg-cyan-glow/5 border border-cyan-glow/30 mb-2"
              >
                <Compass className="w-8 h-8 text-cyan-glow animate-spin" style={{ animationDuration: "50s" }} />
                <div className="absolute inset-0 bg-cyan-glow/10 rounded-full blur-md" />
              </motion.div>

              <motion.h1
                initial={{ letterSpacing: "0.15em", opacity: 0 }}
                animate={{ letterSpacing: "0.3em", opacity: 1 }}
                transition={{ delay: 0.5, duration: 1.2 }}
                className="text-5xl md:text-7xl font-sans font-black tracking-widest text-[#f3f4f6]"
              >
                HELIX<span className="text-gradient-cyan glow-cyan">NOVA</span>
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 0.65, y: 0 }}
                transition={{ delay: 0.8, duration: 0.8 }}
                className="font-mono text-xs md:text-sm tracking-widest uppercase text-white/60 mb-3"
              >
                An Audiovisual Odyssey Through the Cosmos of Biological Creation
              </motion.p>

              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 0.45 }}
                transition={{ delay: 1, duration: 1 }}
                className="text-xs md:text-sm text-white/70 max-w-xl leading-relaxed font-sans font-extralight"
              >
                Travel through galaxies, hydrothermal vents, helical code strands, protein fold models, and digital synaptic vectors. Every pixel holds intention. Every chapter hosts biological wonder.
              </motion.p>

              {/* Start Trigger Button */}
              <motion.button
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.2, duration: 0.8 }}
                onClick={() => setIntroActive(false)}
                className="mt-6 px-10 py-4 rounded-full bg-gradient-to-r from-cyan-glow/20 and via-black/80 to-violet-glow/25 border border-cyan-glow/40 text-cyan-glow font-mono text-xs tracking-widest font-black uppercase hover:scale-105 hover:border-cyan-glow hover:shadow-[0_0_25px_rgba(0,240,255,0.4)] active:scale-95 transition-all duration-300 pointer-events-auto cursor-pointer flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-cyan-glow animate-pulse" />
                INITIATE BIOLOGICAL DRIFT
              </motion.button>
            </main>

            {/* Bottom minimal disclaimer lines */}
            <footer className="w-full flex justify-between items-center max-w-7xl font-mono text-[9px] text-white/30 uppercase">
              <span>SUPPORT INTEGRATES STEREO SYNTH AUDIO</span>
              <span>SCROLL OR SELECT TO DRIFT</span>
            </footer>
          </motion.div>
        ) : (
          /* --- MASTER CINEMATIC EXHIBIT CORE --- */
          <div key="exhibit-layout" className="relative z-10 w-full min-h-screen pb-24 pt-24 font-sans select-none flex flex-col justify-center">
            
            {/* Heads Up Navigation */}
            <Navigation
              chapters={CHAPTERS}
              currentChapter={currentChapter}
              onSelectChapter={handleSelectChapter}
            />

            {/* Cinematic Slide Frame container */}
            <main className="w-full max-w-7xl mx-auto px-6 md:px-12 py-4 flex flex-col lg:flex-row items-center gap-12 justify-center">
              
              {/* Left Column: Narrative prose and text layout */}
              <div className="w-full lg:w-1/2 flex flex-col gap-5 justify-center leading-relaxed">
                
                {/* Stage tag index */}
                <div className="flex items-center gap-3 font-mono text-xs text-white/40">
                  <span className="text-white/20">STAGE COORD:</span>
                  <span className="text-[#bfdbfe] font-black uppercase tracking-wider">CHAPTER 0{currentChapter.id}</span>
                  <span className="text-white/20">|</span>
                  <span className="text-cyan-glow/85 glow-cyan tracking-widest font-bold uppercase">{currentChapter.narrativeTime}</span>
                </div>

                {/* Chapter Title display */}
                <motion.div
                  key={`text-title-${currentChapter.id}`}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.8, ease: "easeOut" }}
                >
                  <h2 className="text-4xl md:text-6xl font-serif font-semibold text-white tracking-tight leading-none mb-1">
                    {currentChapter.title}
                  </h2>
                  <p className="text-xs uppercase font-mono tracking-widest text-[#a855f7] italic brightness-110">
                    {currentChapter.scientificTerm}
                  </p>
                </motion.div>

                {/* Narrative core and segment logs */}
                <motion.div
                  key={`text-desc-${currentChapter.id}`}
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2, duration: 0.8 }}
                  className="flex flex-col gap-4"
                >
                  <p className="text-sm text-white/80 font-sans leading-relaxed pr-6">
                    {currentChapter.summary}
                  </p>
                  
                  <div className="flex gap-3.5 bg-white/5 border border-white/5 p-4 rounded-2xl">
                    <Info className="w-5 h-5 text-cyan-glow flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-white/60 leading-relaxed font-sans italic font-light">
                      {currentChapter.storySegment}
                    </p>
                  </div>
                </motion.div>

                {/* Next Page shortcut guidance */}
                <div className="flex items-center gap-4 mt-2">
                  <button
                    onClick={() => {
                      const prevId = currentChapter.id > 1 ? (currentChapter.id - 1) as ChapterId : 10;
                      handleSelectChapter(prevId);
                    }}
                    className="p-2 rounded-full bg-white/5 border border-white/10 text-white/50 hover:text-white hover:scale-105 active:scale-95 transition-all pointer-events-auto cursor-pointer"
                    title="Previous Chapter"
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </button>

                  <button
                    onClick={() => {
                      const nextId = currentChapter.id < 10 ? (currentChapter.id + 1) as ChapterId : 1;
                      handleSelectChapter(nextId);
                    }}
                    className="px-6 py-2 rounded-full bg-cyan-glow/5 border border-cyan-glow/30 text-cyan-glow font-mono text-xs font-bold uppercase hover:bg-cyan-glow/15 hover:border-cyan-glow transition-all flex items-center gap-1.5 pointer-events-auto cursor-pointer hover:scale-105 active:scale-95"
                  >
                    <span>DRIFT NEXT</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => setIntroActive(true)}
                    className="text-[10px] font-mono text-white/30 hover:text-white transition-colors cursor-pointer"
                  >
                    BACK TO OVERVIEW
                  </button>
                </div>
              </div>

              {/* Right Column: Immersive interactive sandboxes */}
              <div className="w-full lg:w-1/2 flex items-center justify-center z-10">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={`sandbox-${currentChapter.id}`}
                    initial={{ opacity: 0, scale: 0.95, filter: "blur(10px)" }}
                    animate={{ opacity: 1, scale: 1, filter: "blur(0px)" }}
                    exit={{ opacity: 0, scale: 1.05, filter: "blur(10px)" }}
                    transition={{ duration: 0.7, ease: [0.25, 1, 0.5, 1] }}
                    className="w-full flex justify-center"
                  >
                    {renderChapterSandbox()}
                  </motion.div>
                </AnimatePresence>
              </div>

            </main>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
